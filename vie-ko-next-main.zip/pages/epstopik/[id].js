import React from 'react'
import Exam from '../../components/exam'
import Axios from '../../components/apiRequest/Axios'


export async function getServerSideProps() {
    try {
     const resp = await Axios({method: "get", url: '/question/1'})
     return {
       props: {
        questions: await resp.data
       }
     }
    } catch (error) {
      return {
        props: {
          err: ""
        }
      }
    }
  }

const Exams = ({
    questions
}) => {
  return (
    <Exam questions={questions}/>
  )
}

export default Exams