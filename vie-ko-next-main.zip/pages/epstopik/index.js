import React from 'react'
import Exam from '../../components/exam'
import Cookies from 'universal-cookie'
import jwt_decode from "jwt-decode";
import Link from 'next/link';
import Image from 'next/image'
import Axios from '../../components/apiRequest/Axios'


export async function getServerSideProps() {
  try {
   const resp = await Axios({method: "get", url: '/question'})
   return {
     props: {
      questionBanks: await resp.data,
     }
   }
  } catch (error) {
    return {
      props: {
        err: ""
      }
    }
  }
}


const Exams = ({
  questionBanks,
}) => {
  const cookie = new Cookies()
  const token = cookie.get("TOKEN")

  const [decoded, setdecoded] = React.useState([])
  const [question, setquestion] = React.useState([])
  // random to choose exam
  const random = Math.floor(Math.random() * 10);
  const pracIds = questionBanks.map(d => d.prac_id)
  const quesMax = Math.max(...Object.values(pracIds))
  console.log(quesMax)

  React.useEffect(() => {
    let mounded = true
    if(token&&mounded){
      setdecoded(jwt_decode(token))
    }
    if(questionBanks){
      setquestion(questionBanks)
    }
    return ()=> (mounded = false)
  },[token,questionBanks])
  return (
    <div className='container'>
      <span className='p-0 m-0'>Version 1.0</span>
      <div className='row border border-warning rounded'>
        <div className='pt-2 pb-2'>
          <div className='text-center'><img width={50} src='/media/img/logo.png' alt=''/></div>
        </div>
        <hr />
        <div>
          <h3 className='text-center'>Test of proficiency in Korean - Thi năng lực tiếng Hàn</h3>
        </div>
        <hr />
        <div>
          <h5 className='text-center'>Mời bạn chọn đề từ list - 선택하십시요</h5>
          <div className="row m-0 bg-secondary rounded">
            <div className="row container m-auto ">
              <div className="col-lg-6 col-xl-6 text-center pt-5 pb-5">
                <img src="/media/img/Bank.png" alt="" style={{maxWidth: "250px"}} />
                <h3 className="mt-5 text-light">List of Exams <img width="30" src="/media/img/arrow.gif" alt="" style={{transform: "rotate(-90deg)"}} /></h3>
              </div>
              <div className="col-lg-6 col-xl-6 text-center pt-5 pb-5">
                <div className="row">
                    {Array.from(Array(quesMax).keys()).map((key => 
                    <div className="col-3 m-0 p-1" key={key}>
                      <Link href={`/epstopik/exam/${key+1}`}><a>
                        <button style={{minWidth: "80px"}} className="btn btn-exam fs-5 ps-4 pe-4">{key+1}</button>
                      </a></Link>
                    </div>))}
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className='pt-2'>
          <h3 className='text-center'>Hoặc có thể chọn đề tự động - 자동으로 시험 응시</h3>
          <div className='text-center mb-3'>
            <Link href={`/epstopik/exam/${random}`} passHref><button className='btn btn-exam fs-3 pt-3 pb-3 ps-4 pe-4'>바로 시험을 시작하기
            {' '}<img className='ps-1' width="25" src="/media/img/arrow.gif" alt="" style={{transform: "rotate(-90deg)"}} /></button></Link>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Exams