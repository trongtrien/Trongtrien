export default function handler (req, res) {
    res.send([
        {
            name: "trongtrien",
            age: "35"
        }
    ])
}