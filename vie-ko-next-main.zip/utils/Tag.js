import React from 'react'
import Link from 'next/link'

const Tag = () => {
  return (
    <div className="rounded border border-warning ps-3 pt-1">
        <h4 className="text-main-b-dl pt-3 pb-2">Có thể bạn quan tâm</h4>
            <div style={{listStyle: "none"}} className='pb-2'>
            <li className='ps-2 pt-2 pb-2 mb-2 text-light me-3 rounded-3 bg-white'>
                <Link href="/Course/Chapter1"><a>Khóa học EPS-TOPK 1</a></Link>
            </li>
            <li className='ps-2 pt-2 pb-2 mb-2 text-light me-3 rounded-3 bg-white'>
            <Link href="/Course/Chapter2"><a>Khóa học EPS-TOPK 2</a></Link>
            </li>
            <li className='ps-2 pt-2 pb-2 mb-2 text-light me-3 rounded-3 bg-white'>
                <a href="/Exam">
                            Làm đề thi thử</a>
            </li>
            <li className='ps-2 pt-2 pb-2 mb-2 text-light me-3 rounded-3 bg-white'>
                <Link href="/Course/Practice-listen"><a>Ôn bộ đề 1000 câu nghe</a></Link>
            </li>
            <li className='ps-2 pt-2 pb-2 mb-2 text-light me-3 rounded-3 bg-white'>
            <Link href="/Course/Practice-read"><a>Ôn bộ đề 1000 câu đọc</a></Link>
            </li>
            </div>
    </div>
  )
}

export default Tag