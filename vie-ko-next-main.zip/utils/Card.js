/* eslint-disable @next/next/no-img-element */
import React from 'react'
import Link from 'next/link'

const AboutCard = ({imgUrl, link, title}) => {
  return (
    <div className="col-sm-6 col-lg-3 text-center mt-5 ">
        <div className='bg-dl-img rounded-circle m-auto' style={{width: "150px", padding: "28px"}}>
            <img style={{width: "100%"}} src={imgUrl} alt='' />
        </div>
        <div className='mt-5'>
            <Link href={link}><a className='text-dl'><h4 className='text-center'>{title}</h4></a></Link>
        </div>
    </div>
  )
}

const EpsCard = ({data}) => {

    return (
            <div className='rounded p-0' style={{border: "solid 1px rgba(0,0,0,0.1)"}}>
                <div className='ratio ratio-16x9 epscard-after'>
                    <img style={{width: "100%"}} src={`/media/img/E-learning-1.jpg`} alt='' />
                    <Link href={data.link}><a className='epscard-after-btn'>Xem khóa học</a></Link>
                </div>
                <div className='d-flex p-2 pt-3' style={{alignItems: "center"}}>
                    <span className='btn btn-main-y rounded-pill'>Tiếng hàn EPS - TOPIK</span>
                    <span className='btn ms-auto fs-5'>$ <i className='text-success'>Free</i></span>
                </div>
                <div className='p-2 m-0'>
                    <Link href={data.link} passHref><h4 className='m-0 p-0 pb-2 text-main-b-dl'>{data.title}</h4></Link>
                    <p dangerouslySetInnerHTML={{__html: data.description}}/>
                </div>
                <hr className='p-0 m-0'/>
                <div className='d-flex p-2 align-middle' style={{alignItems: "center"}}>
                    <span className='p-0 m-0 fs-4 text-logo-b'>
                        <img style={{width: "50px"}} src={`/media/img/avatars/${data.author}`} alt='avatar'/>
                        &nbsp;Admin
                    </span>
                    <span className='ms-auto align-middle'>
                        <i className="fa fa-user-o text-success" aria-hidden="true"></i>
                        <span className='text-secondary ps-1'>{data.pageview}</span>
                        <i className="fa fa-heart-o ps-3 text-danger" aria-hidden="true"></i>
                        <span className='text-secondary ps-1'>555</span>
                    </span>
                </div>
            </div>)
//     <div className="col-sm-12 col-md-6 col-lg-6 col-xl-3 mt-5">
//         <div className='shadow rounded-3 bg-secondary'>
//     <div className='ratio ratio-16x9 epscard-after'>
//         <img className='rounded-top border-bottom' src={`/media${imgUrl}`} alt='' />
//         <Link href={link}><a className='epscard-after-btn'>Xem khóa học</a></Link>
//     </div>
//     <div className='mt-1 ps-2 pe-2 pb-2'>
//         <Link href={link} passHref><h4 className='text-light mb-0'>{title}</h4></Link>
//         <p className='text-light' dangerouslySetInnerHTML={{__html:description+' ...'}} />
//         <hr />
//         <div className='d-flex fs-5'>
//             <span className='text-light me-auto pb-2'>
//                 <i className="fa fa-users" aria-hidden="true"></i> {view}
//             </span>
//         </div>
        
//     </div>
    
//     </div>
// </div>)
}
export {AboutCard, EpsCard}