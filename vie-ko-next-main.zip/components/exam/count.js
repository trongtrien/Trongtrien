import React from "react";
import secondsToTime from "../../lib/secondsTo_h_m_s";

export function CountDown(seconds){
    const [second, setSecond] = React.useState(seconds)
    React.useEffect(() => {
        let unmounded = true
        if(second>0&&unmounded){
            setInterval(() => setSecond(prev => prev  -1 ), 1000)
        }
        clearInterval(second)
    },[])
  return {second}
}


class Example extends React.Component {
    constructor() {
      super();
      this.state = { time: {}, seconds: 120 };
      this.timer = 0;
      this.startTimer = this.startTimer.bind(this);
      this.countDown = this.countDown.bind(this);
    }
  
    componentDidMount() {
      let timeLeftVar = this.secondsToTime(this.state.seconds);
      this.setState({ time: timeLeftVar });
    }
  
    startTimer() {
      if (this.timer === 0 && this.state.seconds > 0) {
        this.timer = setInterval(this.countDown, 1000);
      }
    }
  
    countDown() {
      // Remove one second, set state so a re-render happens.
      let seconds = this.state.seconds - 1;
      this.setState({
        time: secondsToTime(seconds),
        seconds: seconds,
      });
      
      // Check if we're at zero.
      if (seconds === 0) { 
        clearInterval(this.timer);
      }
    }
  
    render() {
      return(
        <div className="container">
          <button onClick={this.startTimer}>Start</button>
          m: {this.state.time.m<10?'0':''}{this.state.time.m} s: {this.state.time.s<10?'0':''}{this.state.time.s}
        </div>
      );
    }
  }

  export default Example