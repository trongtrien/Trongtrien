import React from 'react'
import SendResuit from './sendResult'

const ScoreSheet = ({
    score,
    questions,
    examId,
    name,
    email
}) => {
  const [showScore, setShowScore] = React.useState(false)
  return (
    <div>
        <SendResuit
        score={score}
        examId={examId}
        name={name}
        setShowScore={setShowScore}
        email={email}/>
        {showScore&&<div>
                      <h1 className=" font-semibold text-center">You scored {score} out of {questions.length}</h1>
                    </div>}
    </div>
  )
}

export default ScoreSheet