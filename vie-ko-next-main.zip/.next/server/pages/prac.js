"use strict";
(() => {
var exports = {};
exports.id = 4006;
exports.ids = [4006];
exports.modules = {

/***/ 6643:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "default": () => (/* binding */ Prac)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_practice_Prac1__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9692);
/* harmony import */ var _components_apiRequest_Axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8420);




async function getServerSideProps() {
    try {
        const resp = await (0,_components_apiRequest_Axios__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)({
            method: "get",
            url: '/question/1'
        });
        return {
            props: {
                questions: await resp.data
            }
        };
    } catch (error) {
        return {
            props: {
                err: ""
            }
        };
    }
}
function Prac({ questions  }) {
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "bg-white",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_practice_Prac1__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
            questions: questions
        })
    }));
};


/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 271:
/***/ ((module) => {

module.exports = require("sweetalert2");

/***/ }),

/***/ 6153:
/***/ ((module) => {

module.exports = require("universal-cookie");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [8901,3297,9692], () => (__webpack_exec__(6643)));
module.exports = __webpack_exports__;

})();