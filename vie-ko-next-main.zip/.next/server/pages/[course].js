"use strict";
(() => {
var exports = {};
exports.id = 503;
exports.ids = [503];
exports.modules = {

/***/ 2590:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_DefaultLayout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8857);
/* harmony import */ var _components_apiRequest_Axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8420);
/* harmony import */ var _utils_Card__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1712);

/* eslint-disable @next/next/no-img-element */ 



async function getServerSideProps() {
    const r = await (0,_components_apiRequest_Axios__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)({
        method: "GET",
        url: "/courseviews"
    });
    return {
        props: {
            list: await r.data.filter((d)=>d.id < 18
            )
        }
    };
}
const Course = ({ list  })=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_DefaultLayout__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "container",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "bg-success rounded bg-opacity-10 p-2 mt-2",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                            className: "text-dl mt-4 mb-4 text-center",
                            children: "Con đường ch\xf4ng gai từ đ\xe2y bạn nh\xe9 ...!!!"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h3", {
                            className: "text-center text-success mb-4",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "mt-5 mb-5 text-dl",
                                    style: {
                                        fontSize: "30px"
                                    },
                                    children: "***** 💼 💼 💼 *****"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("em", {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                        children: "H\xf9 bạn ch\xfat th\xf4i ch\xf4ng gai n\xe0o nếu cố gắng đều sẽ vượt qua ...!"
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                            className: "text-dl pt-0 text-center",
                            children: [
                                "Khi c\xe1c bạn đọc đến những d\xf2ng n\xe0y th\xec m\xecnh tin l\xe0 c\xe1c bạn đ\xe3 c\xf3 những mục ti\xeau cho bản th\xe2n, v\xe0 c\xf3 những kế hoạch cụ thể cho việc học tiếng H\xe0n rồi phải kh\xf4ng ạ.",
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                "C\xf2n với m\xecnh cũng sẽ cố gắng thật nhiều để mang đến cho c\xe1c bạn những kiến thức b\xe0i giảng với hết khả năng của m\xecnh.",
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                "V\xe0 cốt l\xf5i nhất l\xe0 kiến thức n\xean m\xecnh cố gắng x\xe2y dựng giao diện đơn gian nhất c\xf3 thể (thật ra l\xe0 một phần do c\xf2n g\xe0 về lập tr\xecnh kaka).",
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                "Tr\xecnh b\xe0y sao cho c\xe1c bạn dễ đọc, dễ hiểu nhất, v\xe0 đặc biệt l\xe0 n\xf3 ho\xe0n to\xe0n miễn ph\xed. V\xe0 với tất cả những điều đ\xf3 rất mong l\xe0 c\xe1c bạn chăm học để đạt kết quả như mong muốn.",
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                "Sẽ chẳng thể một lần m\xe0 ho\xe0n thiện được ngay n\xean trong qu\xe1 tr\xecnh học c\xf3 chỗ n\xe0o lỗi cả về giao diện cả về nội dung th\xec c\xe1c bạn h\xe3y phản hồi về cho m\xecnh nh\xe9.",
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                "C\xf2n về việc học online sao cho hiệu quả th\xec tr\xean internet cũng c\xf3 h\xe0ng trăm ngh\xecn b\xe0i viết chia sẻ về điều đ\xf3 v\xe0 trong một b\xe0i viết m\xecnh cũng c\xf3 n\xf3i qua về điều đ\xf3, v\xe0 bản th\xe2n cũng l\xe0 một người học tập rất nhiều thứ từ internet v\xed như chuyện viết n\xean trang web n\xe0y cũng ho\xe0n to\xe0n l\xe0 học tr\xean mạng cả n\xean c\xe1c bạn c\xe1c quyết t\xe2m nha 💪💪💪💪💪"
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "mt-2",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                        className: "text-dl text-main-b-dl",
                        children: [
                            "\xa0",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                height: 40,
                                src: "/media/img/mui_ten_r.png",
                                alt: ""
                            }),
                            "\xa0Kh\xf3a học cho bạn"
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "row",
                    children: list.map((l, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-md-6 col-lg-4 p-2",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_utils_Card__WEBPACK_IMPORTED_MODULE_4__/* .EpsCard */ .x, {
                                data: l
                            })
                        }, i)
                    )
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "bg-success rounded bg-opacity-10 p-2 mt-2",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                        className: "text-dl",
                        children: "Con đường ch\xf4ng gai từ đ\xe2y bạn nh\xe9 ...!!!"
                    })
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Course);


/***/ }),

/***/ 4173:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Close");

/***/ }),

/***/ 3684:
/***/ ((module) => {

module.exports = require("@mui/icons-material/LightMode");

/***/ }),

/***/ 216:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Link");

/***/ }),

/***/ 984:
/***/ ((module) => {

module.exports = require("@mui/icons-material/MenuTwoTone");

/***/ }),

/***/ 9476:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Nightlight");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 5567:
/***/ ((module) => {

module.exports = require("jwt-decode");

/***/ }),

/***/ 1162:
/***/ ((module) => {

module.exports = require("next-themes");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 6153:
/***/ ((module) => {

module.exports = require("universal-cookie");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [7190,676,1664,8901,7374,1035,8857,1712], () => (__webpack_exec__(2590)));
module.exports = __webpack_exports__;

})();