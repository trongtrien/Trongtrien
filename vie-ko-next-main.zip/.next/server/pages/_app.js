"use strict";
(() => {
var exports = {};
exports.id = 2888;
exports.ids = [2888];
exports.modules = {

/***/ 1799:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
var router_default = /*#__PURE__*/__webpack_require__.n(router_);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
;// CONCATENATED MODULE: ./components/loadding/index.js



const Loadding = ()=>{
    const styles = {
        position: "fixed",
        top: "0",
        bottom: "0",
        left: "0",
        right: "0",
        backgroundColor: "#ffffff",
        zIndex: "1000"
    };
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        style: styles,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            style: {
                position: "absolute",
                margin: "auto",
                top: "48%",
                left: "50%",
                transform: "translateX(-50%)",
                alignItem: "center",
                textAlign: "center"
            },
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                    src: "/media/img/loadding.svg",
                    alt: "loadding",
                    width: 60,
                    height: 60
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                    children: "loadding ..."
                })
            ]
        })
    }));
};
/* harmony default export */ const components_loadding = (Loadding);

// EXTERNAL MODULE: external "next-themes"
var external_next_themes_ = __webpack_require__(1162);
;// CONCATENATED MODULE: external "next/script"
const script_namespaceObject = require("next/script");
var script_default = /*#__PURE__*/__webpack_require__.n(script_namespaceObject);
;// CONCATENATED MODULE: ./lib/gtag.js
const GA_TRACKING_ID = "G-7WR30E4V3P";
// https://developers.google.com/analytics/devguides/collection/gtagjs/pages
const pageview = (url)=>{
    window.gtag('config', GA_TRACKING_ID, {
        page_path: url
    });
};
// https://developers.google.com/analytics/devguides/collection/gtagjs/events
const gtag_event = ({ action , category , label , value  })=>{
    window.gtag('event', action, {
        event_category: category,
        event_label: label,
        value: value
    });
};

;// CONCATENATED MODULE: ./components/Script.js





const ScriptElement = ()=>{
    const router = (0,router_.useRouter)();
    external_react_default().useEffect(()=>{
        const handleRouteChange = (url)=>{
            pageview(url);
        };
        router.events.on('routeChangeComplete', handleRouteChange);
        router.events.on('hashChangeComplete', handleRouteChange);
        return ()=>{
            router.events.off('routeChangeComplete', handleRouteChange);
            router.events.off('hashChangeComplete', handleRouteChange);
        };
    }, [
        router.events
    ]);
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((script_default()), {
                strategy: "afterInteractive",
                src: `https://www.googletagmanager.com/gtag/js?id=${GA_TRACKING_ID}`
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((script_default()), {
                id: "gtag-init",
                strategy: "afterInteractive",
                dangerouslySetInnerHTML: {
                    __html: `
                window.dataLayer = window.dataLayer || [];
                function gtag(){dataLayer.push(arguments);}
                gtag('js', new Date());
                gtag('config', '${GA_TRACKING_ID}', {
                page_path: window.location.pathname,
                });
            `
                }
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((script_default()), {
                id: "fb-script",
                strategy: "afterInteractive",
                dangerouslySetInnerHTML: {
                    __html: `
              window.fbAsyncInit = function() {
                FB.init({
                  appId      : '155570839747933',
                  xfbml      : true,
                  version    : 'v13.0'
                });
                FB.AppEvents.logPageView();
              };
            
              (function(d, s, id){
                 var js, fjs = d.getElementsByTagName(s)[0];
                 if (d.getElementById(id)) {return;}
                 js = d.createElement(s); js.id = id;
                 js.src = "https://connect.facebook.net/vi_VN/sdk.js";
                 fjs.parentNode.insertBefore(js, fjs);
               }(document, 'script', 'facebook-jssdk'));
            `
                }
            })
        ]
    }));
};
/* harmony default export */ const Script = (ScriptElement);

;// CONCATENATED MODULE: ./pages/_app.js

/* eslint-disable @next/next/inline-script-id */ 







function MyApp({ Component , pageProps  }) {
    const { 0: loadding , 1: setLoadding  } = (0,external_react_.useState)(false);
    router_default().events.on('routeChangeStart', ()=>{
        setLoadding(true);
    });
    router_default().events.on('routeChangeComplete', ()=>{
        setLoadding(false);
    });
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((head_default()), {
                children: /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                    name: "viewport",
                    content: "width=device-width, initial-scale=1.0, maximum-scale=1.0"
                })
            }),
            loadding && /*#__PURE__*/ jsx_runtime_.jsx(components_loadding, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(external_next_themes_.ThemeProvider, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                    ...pageProps
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Script, {})
        ]
    }));
}
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 1162:
/***/ ((module) => {

module.exports = require("next-themes");

/***/ }),

/***/ 8028:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [7190,5675], () => (__webpack_exec__(1799)));
module.exports = __webpack_exports__;

})();