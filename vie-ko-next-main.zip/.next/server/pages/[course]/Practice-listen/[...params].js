"use strict";
(() => {
var exports = {};
exports.id = 1093;
exports.ids = [1093];
exports.modules = {

/***/ 4441:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "default": () => (/* binding */ Home)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_courses_Practice__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5486);
/* harmony import */ var _components_CourseLayout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5595);
/* harmony import */ var _components_seo__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7187);
/* harmony import */ var _components_apiRequest_Axios__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8420);
/* harmony import */ var _utils_isMobile__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9274);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6153);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(universal_cookie__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var jwt_decode__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5567);
/* harmony import */ var jwt_decode__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(jwt_decode__WEBPACK_IMPORTED_MODULE_8__);

/* eslint-disable @next/next/no-img-element */ 







async function getServerSideProps({ params  }) {
    try {
        const id = params.params[0].slice(6, -1);
        const lesson = await (0,_components_apiRequest_Axios__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)({
            method: "get",
            url: `/practice-listen/${id}`
        });
        const lessons = await (0,_components_apiRequest_Axios__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)({
            method: "get",
            url: 'practice-listen'
        });
        const courseviews = await (0,_components_apiRequest_Axios__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)({
            method: "get",
            url: '/courseviews/4'
        });
        const dic = await (0,_components_apiRequest_Axios__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)({
            method: "GET",
            url: `/gamesQ/${id}`
        });
        const progress = await (0,_components_apiRequest_Axios__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)({
            method: "GET",
            url: '/progress'
        });
        return {
            props: {
                lesson: await lesson.data,
                listLessons: await lessons.data,
                dataDic: await dic.data,
                progress: await progress.data,
                courseview: await courseviews.data,
                para: params
            }
        };
    } catch (error) {
        return {
            err: "Error: Not connected. Please check your Internet connection and try"
        };
    }
}
function Home({ lesson , listLessons , dataDic , para , err , courseview , progress  }) {
    // token
    const cookie = new (universal_cookie__WEBPACK_IMPORTED_MODULE_7___default())();
    const token = cookie.get('TOKEN');
    const [decoded, setDecoded] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(true);
    react__WEBPACK_IMPORTED_MODULE_1___default().useEffect(()=>{
        if (token) {
            setDecoded(jwt_decode__WEBPACK_IMPORTED_MODULE_8___default()(token));
        }
    }, [
        token
    ]);
    const id = Number(para.params[0].slice(6, -1));
    const titleParam = para.params[0].slice(0, -3);
    const course = para.course;
    const link = 'Practice-listen';
    //  progress
    const progresses = progress.find((p)=>p.course_id == 4
    );
    // show hide menu
    const [showMenu, setShowMenu] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(true);
    const isMobile = (0,_utils_isMobile__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)('1200');
    react__WEBPACK_IMPORTED_MODULE_1___default().useEffect(()=>{
        if (!isMobile) {
            setShowMenu(true);
        } else {
            setShowMenu(false);
        }
    }, [
        isMobile
    ]);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_CourseLayout__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        link: link,
        setShowMenu: setShowMenu,
        showMenu: showMenu,
        chapterLabel: "듣기",
        lesonLabel: `${titleParam}`,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_seo__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                title: lesson.title,
                description: "Kh\xf3a học tiếng H\xe0n EPS-TOPIK - \xd4n bộ đề 960 c\xe2u nghe. Ch\xfang t\xf4i t\xe2m huyết - c\xe1c bạn nỗ lực, th\xe0nh c\xf4ng sẽ đến l\xe0 chuyện kh\xf4ng ảo tưởng",
                imgUrl: courseview.imgUrl
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_courses_Practice__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                link: link,
                lesson_ssr: lesson,
                courseId: '4',
                listLesson: listLessons,
                showMenu: showMenu,
                token: token,
                progresses: progresses,
                dataDic: dataDic,
                idParam: id
            })
        ]
    }));
};


/***/ }),

/***/ 4173:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Close");

/***/ }),

/***/ 984:
/***/ ((module) => {

module.exports = require("@mui/icons-material/MenuTwoTone");

/***/ }),

/***/ 7185:
/***/ ((module) => {

module.exports = require("@mui/material/Breadcrumbs");

/***/ }),

/***/ 5246:
/***/ ((module) => {

module.exports = require("@mui/material/Link");

/***/ }),

/***/ 8742:
/***/ ((module) => {

module.exports = require("@mui/material/Stack");

/***/ }),

/***/ 5858:
/***/ ((module) => {

module.exports = require("@mui/material/Typography");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 5567:
/***/ ((module) => {

module.exports = require("jwt-decode");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 1701:
/***/ ((module) => {

module.exports = require("react-player/youtube");

/***/ }),

/***/ 6158:
/***/ ((module) => {

module.exports = require("react-share");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 4701:
/***/ ((module) => {

module.exports = require("sweetalert");

/***/ }),

/***/ 271:
/***/ ((module) => {

module.exports = require("sweetalert2");

/***/ }),

/***/ 6153:
/***/ ((module) => {

module.exports = require("universal-cookie");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [7190,676,1664,8901,7374,7187,2088,3297,5595,2110,5486], () => (__webpack_exec__(4441)));
module.exports = __webpack_exports__;

})();