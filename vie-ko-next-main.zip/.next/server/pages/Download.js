"use strict";
(() => {
var exports = {};
exports.id = 2796;
exports.ids = [2796];
exports.modules = {

/***/ 6162:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Download),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "@emailjs/browser"
var browser_ = __webpack_require__(7163);
var browser_default = /*#__PURE__*/__webpack_require__.n(browser_);
;// CONCATENATED MODULE: external "@mui/icons-material/FileDownload"
const FileDownload_namespaceObject = require("@mui/icons-material/FileDownload");
var FileDownload_default = /*#__PURE__*/__webpack_require__.n(FileDownload_namespaceObject);
// EXTERNAL MODULE: external "@mui/icons-material/Close"
var Close_ = __webpack_require__(4173);
var Close_default = /*#__PURE__*/__webpack_require__.n(Close_);
// EXTERNAL MODULE: ./utils/Tag.js
var Tag = __webpack_require__(8694);
// EXTERNAL MODULE: ./utils/share/ShareSocial.js
var ShareSocial = __webpack_require__(2088);
// EXTERNAL MODULE: ./components/apiRequest/Axios.js
var Axios = __webpack_require__(8420);
// EXTERNAL MODULE: ./components/DefaultLayout.js + 3 modules
var DefaultLayout = __webpack_require__(8857);
// EXTERNAL MODULE: ./components/ads/DisplayAds.js
var DisplayAds = __webpack_require__(1735);
;// CONCATENATED MODULE: ./pages/Download.js

/* eslint-disable @next/next/no-img-element */ 



// import Fbcomment from '../hooks/Fbcomment'





async function getServerSideProps() {
    try {
        const resp = await (0,Axios/* default */.Z)({
            method: "get",
            url: "/courseviews/18"
        });
        return {
            props: {
                view: await resp.data.map((p)=>p.pageview
                )
            }
        };
    } catch (error) {
        return {
            props: {
                err: "Error: not connected. Please check your Internet connection and try"
            }
        };
    }
}
const DownloadTemp = ({ view  })=>{
    const [list, setlist] = external_react_default().useState([]);
    const [show, setShow] = external_react_default().useState(false);
    const [meg, setMeg] = external_react_default().useState('');
    //   download
    const [isDownload, setIsDownload] = external_react_default().useState(false);
    const [urlDownload, seturlDownload] = external_react_default().useState('');
    const [title, settitle] = external_react_default().useState('');
    const [seconds, setSeconds] = external_react_default().useState(0);
    (0,external_react_.useEffect)(()=>{
        if (seconds > 0) {
            setTimeout(()=>setSeconds((prev)=>prev - 1
                )
            , 1000);
        }
        return ()=>clearTimeout(seconds)
        ;
    }, [
        seconds
    ]);
    const [sendStatus, setSendStatus] = external_react_default().useState(false);
    const form = external_react_default().useRef();
    //   share social
    const [showShare, setShowShare] = external_react_default().useState(false);
    (0,external_react_.useEffect)(()=>{
        setlist(window.listdownload);
        (0,Axios/* default */.Z)({
            method: 'PUT',
            url: '/courseviews/18'
        });
    }, []);
    const sendEmail = (e)=>{
        e.preventDefault();
        browser_default().sendForm('service_y9ia8nd', 'template_dsnh7ls', form.current, 'drEmL9JG_FYfIX-VM').then((result)=>{
            setMeg('Đ\xe3 tiếp nhận y\xeau cầu, ch\xfang t\xf4i sẽ gửi t\xe0i liệu cho bạn sớm nhất c\xf3 thể!');
        }, (error)=>{
            setMeg('C\xf3 vẻ như bạn chưa nhập đ\xfang, đủ c\xe1c trường th\xf4ng tin b\xean dưới');
        });
    };
    return(/*#__PURE__*/ jsx_runtime_.jsx(DefaultLayout/* default */.Z, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container bg-dl",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "row pt-5",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "col-lg-8 col-xl-9 p-3 download-row",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                className: "p-0 rounded-3",
                                src: "/media/img/eps/doc-dl.jpg",
                                alt: ""
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "d-flex mt-3 text-dl",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "me-auto",
                                        children: "10/05/2022"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                        className: "m-0 p-0 me-3 btn",
                                        onClick: ()=>setShowShare(!showShare)
                                        ,
                                        children: [
                                            "Share ",
                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "fa fa-share-alt text-logo-b",
                                                "aria-hidden": "true"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                        children: [
                                            view ? view : "0",
                                            " ",
                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "fa fa-eye text-logo-b",
                                                "aria-hidden": "true"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            showShare && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "mt-4 bg-secondary bg-opacity-25 rounded pt-3 pb-3 text-center",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(ShareSocial/* default */.Z, {
                                    shareUrl: "/Download",
                                    title: "Tải t\xe0i liệu EPS-TOPIK"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "row pb-4 pt-0 text-dl",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                        children: "Nếu bạn gặp kh\xf3 khăn khi tải c\xf3 thể để lại email bọn m\xecnh sẽ gửi ạ"
                                    }),
                                    !show && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                className: "btn btn-primary p-3",
                                                onClick: ()=>{
                                                    setMeg('');
                                                    setShow(!show);
                                                },
                                                children: "Đăng k\xfd nhận t\xe0i liệu qua email"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h4", {
                                                children: [
                                                    !meg && sendStatus && 'Lỗi rồi, c\xf3 thể bạn nhập chưa đ\xfang th\xf4ng tin',
                                                    meg && sendStatus && meg
                                                ]
                                            })
                                        ]
                                    }),
                                    show && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                                        className: "d-flex flex-column",
                                        ref: form,
                                        onSubmit: sendEmail,
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                                htmlFor: "name",
                                                className: "mt-4",
                                                children: [
                                                    "Name:",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                        name: "name",
                                                        id: "name",
                                                        type: "text",
                                                        className: "form-control",
                                                        placeholder: "Enter Your Name",
                                                        required: true
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                                htmlFor: "email",
                                                className: "mt-4",
                                                children: [
                                                    "Email:",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                        name: "email",
                                                        id: "email",
                                                        type: "email",
                                                        className: "form-control",
                                                        placeholder: "Enter Your Email",
                                                        required: true
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                                htmlFor: "message",
                                                className: "mt-4",
                                                children: [
                                                    "T\xe0i liệu muốn nhận:",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                                                        name: "message",
                                                        id: "message",
                                                        type: "text",
                                                        className: "form-control",
                                                        placeholder: "Enter Your Require",
                                                        rows: 3
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "d-flex",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                        className: "btn btn-primary p-3 mt-5 me-auto",
                                                        type: "submit",
                                                        onClick: ()=>{
                                                            setTimeout(()=>{
                                                                setShow(!show);
                                                                setSendStatus(true);
                                                            }, 1500);
                                                        },
                                                        children: "Submit"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                        className: "btn btn-primary p-3 mt-5",
                                                        type: "reset",
                                                        children: "Reset"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                        className: "btn btn-primary p-3 mt-5",
                                                        type: "reset",
                                                        onClick: ()=>{
                                                            setShow(!show);
                                                        },
                                                        children: "Close"
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    list && list.map((load)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                    className: "mt-5 ms-3 pb-2",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            children: load.headding.toUpperCase()
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                                    className: "text-success mb-3"
                                                }),
                                                load.down.map((down)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        children: [
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h3", {
                                                                className: "mt-5 ms-3 pb-2 download-row-img",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                                        className: "me-3",
                                                                        src: "/media/img/mui_ten_r.png",
                                                                        alt: ""
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                            children: down.title
                                                                        })
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "row m-0 mb-4",
                                                                children: down.links.map((link, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                        className: "col-md-6 col-lg-6 mb-4",
                                                                        children: [
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                                                src: link.imgSrc,
                                                                                alt: ""
                                                                            }),
                                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                                                                type: "button",
                                                                                className: "border-0",
                                                                                onClick: ()=>{
                                                                                    seturlDownload(link.link);
                                                                                    settitle(link.title);
                                                                                    setIsDownload(!isDownload);
                                                                                    setSeconds(10);
                                                                                },
                                                                                children: [
                                                                                    "Download ",
                                                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                                        className: "ms-3",
                                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((FileDownload_default()), {})
                                                                                    })
                                                                                ]
                                                                            })
                                                                        ]
                                                                    }, index)
                                                                )
                                                            })
                                                        ]
                                                    }, down.title)
                                                )
                                            ]
                                        }, load.headding)
                                    ),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: `download-modal ${isDownload && "download-modal-show"} text-light`,
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "download-popup bg-secondary rounded shadow",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "d-flex m-0",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                            className: "ps-3 m-0 pt-3 pb-2",
                                                            children: title && title
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                            className: "m-0 ms-auto pt-2 pb-2 pe-3",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: "btn text-light",
                                                                onClick: ()=>{
                                                                    setIsDownload(!isDownload);
                                                                    setSeconds(0);
                                                                    clearTimeout(seconds);
                                                                },
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((Close_default()), {})
                                                            })
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                                    className: "m-0 p-0"
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "ps-3 pe-3",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx(DisplayAds/* default */.Z, {
                                                            slot: "8882564828"
                                                        }),
                                                        seconds == 0 ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "m-0 fs-5",
                                                                    children: "Mời bạn tải về tại đ\xe2y nh\xe9!"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                    className: "pb-3 m-0 pt-2",
                                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                                        className: "text-warning",
                                                                        href: urlDownload,
                                                                        target: "new",
                                                                        download: true,
                                                                        children: [
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                                                style: {
                                                                                    width: "30px"
                                                                                },
                                                                                src: "/media/img/mui_ten_r.png",
                                                                                alt: ""
                                                                            }),
                                                                            " Download now"
                                                                        ]
                                                                    })
                                                                })
                                                            ]
                                                        }) : /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "m-0 fs-6 pb-3",
                                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                                    className: "m-0 fs-6",
                                                                    children: [
                                                                        "Link download sẽ được trả về trong ",
                                                                        seconds,
                                                                        "s"
                                                                    ]
                                                                })
                                                            })
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "col-lg-4 col-xl-3 mt-3",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(Tag/* default */.Z, {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "rounded border border-warning mt-3 mb-3 ps-3 pe-3",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(DisplayAds/* default */.Z, {
                                    slot: "9005014409"
                                })
                            })
                        ]
                    })
                ]
            })
        })
    }));
};
/* harmony default export */ const Download = (DownloadTemp);


/***/ }),

/***/ 7105:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "F": () => (/* binding */ baseUrl)
/* harmony export */ });
const baseUrl = 'https://eps.vie-ko.com';


/***/ }),

/***/ 7163:
/***/ ((module) => {

module.exports = require("@emailjs/browser");

/***/ }),

/***/ 4173:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Close");

/***/ }),

/***/ 3684:
/***/ ((module) => {

module.exports = require("@mui/icons-material/LightMode");

/***/ }),

/***/ 216:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Link");

/***/ }),

/***/ 984:
/***/ ((module) => {

module.exports = require("@mui/icons-material/MenuTwoTone");

/***/ }),

/***/ 9476:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Nightlight");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 5567:
/***/ ((module) => {

module.exports = require("jwt-decode");

/***/ }),

/***/ 1162:
/***/ ((module) => {

module.exports = require("next-themes");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6158:
/***/ ((module) => {

module.exports = require("react-share");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 6153:
/***/ ((module) => {

module.exports = require("universal-cookie");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [7190,676,1664,8901,7374,1035,8857,2088,6694], () => (__webpack_exec__(6162)));
module.exports = __webpack_exports__;

})();