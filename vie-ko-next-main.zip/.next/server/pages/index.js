"use strict";
(() => {
var exports = {};
exports.id = 5405;
exports.ids = [5405];
exports.modules = {

/***/ 7639:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/apiRequest/Axios.js
var Axios = __webpack_require__(8420);
// EXTERNAL MODULE: ./components/seo.js
var seo = __webpack_require__(7187);
// EXTERNAL MODULE: ./components/DefaultLayout.js + 3 modules
var DefaultLayout = __webpack_require__(8857);
;// CONCATENATED MODULE: ./components/home/Banner.js

/* eslint-disable react/no-unescaped-entities */ /* eslint-disable @next/next/no-img-element */ 
const Banner = ()=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        id: "banner",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                className: "cb-slideshow",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {})
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {})
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {})
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "mt-5 text-light banner",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        children: "WELCOME TO VIE-KO"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        src: "/media/img/wellcome.png",
                        alt: ""
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "mt-5",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            href: "#main",
                            className: "link-box rounded-pill",
                            children: "Let's Go"
                        })
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const home_Banner = (Banner);

// EXTERNAL MODULE: ./utils/Card.js
var Card = __webpack_require__(1712);
;// CONCATENATED MODULE: ./components/home/About.js

/* eslint-disable @next/next/no-img-element */ 

const About = ()=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
            className: "bg-dl",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "container mt80",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "row pt-5 pb-5",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-xl-6 pt-3 pb-3",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "about_thumb",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        style: {
                                            width: "100%"
                                        },
                                        className: "rounded-3",
                                        src: "/media/img/educate.jpg",
                                        alt: ""
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-xl-6 pt-3 pb-3 text-dl",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "about_content",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h3", {
                                            children: [
                                                "T\xe2m sự ch\xfat nh\xe9 ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("em", {
                                                    children: "...!!!"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "text-dl",
                                            children: "Với xuất ph\xe1t điểm l\xe0 một người m\xe0y m\xf2 tự học v\xe0 t\xecm kiếm th\xf4ng tin về chương tr\xecnh eps, v\xe0 đ\xe3 th\xe0nh c\xf4ng. Tuy nhi\xean phải t\xecm kiếm c\xf3p nhặt mỗi nơi một ch\xfat rất vất vả, đ\xf4i l\xfac ph\xe2n v\xe2n kh\xf4ng biết đ\xe2u l\xe0 trọng t\xe2m, cũng kh\xf4ng c\xf3 người đi trước để chỉ dẫn những thủ tục giấy tờ."
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "text-dl",
                                            children: "Ch\xednh v\xec lẽ đ\xf3 m\xecnh đ\xe3 l\xean \xfd tưởng l\xe0m website n\xe0y để chia sẻ lại những kiến thức cũng như kinh nghiệm c\xf3 được khi theo đuổi chương tr\xecnh n\xe0y. Cũng thấy kh\xe1 nhiều trang web về tiếng H\xe0n với nội dung phong ph\xfa v\xe0 những t\xe1c giả đ\xf3 c\xf3 kiến thức rất rộng. Nhưng như tiếu đề của trang web l\xe0 d\xe0nh ri\xeang cho chương tr\xecnh Eps n\xean kiến thức sẽ tập trung hơn, cũng như mọi th\xf4ng tin li\xean quan về chương tr\xecnh n\xe0y m\xecnh cũng cố gắng thu thập t\xecm t\xf2i chia sẻ lại cho c\xe1c bạn ..."
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "container pb-5",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: "text-secondary fw-bold",
                            children: "Bạn c\xf3 g\xec ở đ\xe2y"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "row mb-5 about",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(Card/* AboutCard */.H, {
                                    title: "Kh\xf3a học Full lộ tr\xecnh",
                                    imgUrl: "/media/img/course.png",
                                    link: "#main"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(Card/* AboutCard */.H, {
                                    title: "T\xe0i liệu đầy đủ",
                                    imgUrl: "/media/img/books.png",
                                    link: "/Download"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(Card/* AboutCard */.H, {
                                    title: "Chia sẻ tận t\xecnh",
                                    imgUrl: "/media/img/signpost.png",
                                    link: "/"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(Card/* AboutCard */.H, {
                                    title: "\xd4n tập & thi thử",
                                    imgUrl: "/media/img/learning.png",
                                    link: "/Exam"
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    }));
};
/* harmony default export */ const home_About = (About);

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
;// CONCATENATED MODULE: ./components/home/Eps.js

/* eslint-disable @next/next/no-img-element */ 


function Eps({ data , err  }) {
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        id: "main",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "bg-dl pb-5",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container pb-2",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "d-flex",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                className: "text-secondary fw-bold me-auto",
                                children: "Lộ tr\xecnh học"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: "/Course",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                    className: "fs-4 text-warning",
                                    children: [
                                        "Xem tất cả ",
                                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            width: 30,
                                            src: "/media/img/mui_ten_r.png",
                                            alt: ""
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "row",
                        children: data ? data.map((item, index)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-md-6 col-lg-4 p-2",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(Card/* EpsCard */.x, {
                                    title: item.title,
                                    imgUrl: item.imgUrl,
                                    link: item.link,
                                    view: item.pageview,
                                    description: item.description,
                                    data: item
                                })
                            }, index)
                        ) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                    className: "p-3 text-warning fs-5",
                                    children: [
                                        "! ",
                                        err
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "text-secondary",
                                    children: "Not connected. Please check your Internet connection and try"
                                })
                            ]
                        })
                    })
                ]
            })
        })
    }));
};

;// CONCATENATED MODULE: ./pages/index.js

/* eslint-disable @next/next/no-img-element */ 






async function getServerSideProps() {
    try {
        const r = await (0,Axios/* default */.Z)({
            method: "GET",
            url: "/courseviews"
        });
        const data = await r.data;
        if (!data) return {
            props: {
                err: true
            }
        };
        return {
            props: {
                data: await r.data.sort((a, b)=>a.id - b.id
                ).slice(0, 4)
            }
        };
    } catch (error) {
        return {
            props: {
                err: true
            }
        };
    }
}
function Home({ data  }) {
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(DefaultLayout/* default */.Z, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(seo/* default */.Z, {
                title: "Vieko-Eps • Tiếng H\xe0n xklđ",
                description: "Vieko-Nỗ lực l\xe0 tương lai - Th\xe0nh c\xf4ng chỉ đến khi ta c\xf9ng nhau cố gắng! 화이팅",
                imgUrl: "thumbnail.png"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(home_Banner, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(home_About, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Eps, {
                data: data,
                err: "Error"
            })
        ]
    }));
};


/***/ }),

/***/ 4173:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Close");

/***/ }),

/***/ 3684:
/***/ ((module) => {

module.exports = require("@mui/icons-material/LightMode");

/***/ }),

/***/ 216:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Link");

/***/ }),

/***/ 984:
/***/ ((module) => {

module.exports = require("@mui/icons-material/MenuTwoTone");

/***/ }),

/***/ 9476:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Nightlight");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 5567:
/***/ ((module) => {

module.exports = require("jwt-decode");

/***/ }),

/***/ 1162:
/***/ ((module) => {

module.exports = require("next-themes");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 6153:
/***/ ((module) => {

module.exports = require("universal-cookie");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [7190,676,1664,8901,7374,1035,8857,7187,1712], () => (__webpack_exec__(7639)));
module.exports = __webpack_exports__;

})();