"use strict";
exports.id = 3297;
exports.ids = [3297];
exports.modules = {

/***/ 9575:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6737);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6153);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(universal_cookie__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(271);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);






function Scoresheet({ totalQuestions , score , progress , updateProgress , dntitle , answerList , idParam , titleParam , // chinh la link
link  }) {
    const { 0: nextLesson , 1: setNextLesson  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false) //Hook to check if Exit button was clicked
    ;
    const { 0: prevLesson , 1: setPrevLesson  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false) //Hook to check if Exit button was clicked
    ;
    const { 0: restart , 1: setRestart  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false) //Hook to check if Restart button was clicked
    ;
    const total = totalQuestions;
    const inCorrect = total - score / 5;
    // set disabledClick
    const cookie = new (universal_cookie__WEBPACK_IMPORTED_MODULE_3___default())();
    const token = cookie.get('TOKEN');
    const { 0: disabledClick , 1: setDisabledClick  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const id = idParam;
    console.log(id);
    const title = titleParam;
    console.log(title);
    const disableClick = (Number(id) > 30 ? (Number(id) - 30) * 2 : Number(id) * 2) <= Number(progress);
    const chapter = link;
    console.log(chapter);
    if (chapter === "Practice-listen" || chapter === "Practice-read") {
        let n1 = title.split("-");
        let n2 = n1.map((item)=>Number(item)
        );
        if (nextLesson === true) {
            return next_router__WEBPACK_IMPORTED_MODULE_5___default().push(`${n2[0] + 20}-${n2[1] + 20}(${Number(id) + 1})`);
        }
        if (prevLesson === true) {
            return next_router__WEBPACK_IMPORTED_MODULE_5___default().push(`${n2[0] - 20}-${n2[1] - 20}(${Number(id) - 1})`);
        }
    }
    if (nextLesson === true) {
        return next_router__WEBPACK_IMPORTED_MODULE_5___default().push(`Lesson=${id + 1}-1`);
    }
    if (prevLesson === true) {
        return next_router__WEBPACK_IMPORTED_MODULE_5___default().push(`Lesson=${id - 1}-1`);
    }
    //Restart was clicked so load the Quiz component (pass the username along)
    if (restart === true) {
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(___WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                updateProgress: updateProgress,
                progress: progress,
                idParam: idParam,
                titleParam: titleParam,
                link: link
            })
        }));
    }
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "container-exam",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "scoresheet rounded-3 p-3",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                            className: "pt-4",
                            children: "Bạn đ\xe3 ho\xe0n th\xe0nh b\xe0i kiểm tra"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h3", {
                            children: [
                                "Số c\xe2u trả lời sai ",
                                inCorrect
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                            children: dntitle
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "d-flex p-2",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: "button btn-exam me-auto",
                                    onClick: ()=>setPrevLesson(true)
                                    ,
                                    children: "B\xe0i cũ"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: "button btn-exam me-auto",
                                    onClick: ()=>setRestart(true)
                                    ,
                                    children: "L\xe0m lại"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: "button btn-exam",
                                    onClick: ()=>setNextLesson(true)
                                    ,
                                    children: "B\xe0i mới"
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "scoresheet rounded-3 p-3",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                            children: [
                                inCorrect <= total / 5 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "text-left pb-2",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                            className: "m-0 pb-1",
                                            children: "Bạn đ\xe3 ho\xe0n th\xe0nh xuất x\xe1c b\xe0i kiểm tra"
                                        }),
                                        "➤ Xem kết quả b\xean dưới xem m\xecnh c\xf3 sai ở đ\xe2u kh\xf4ng nh\xe9"
                                    ]
                                }),
                                inCorrect > total / 5 && inCorrect < total / 2 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "text-left pb-2",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                            className: "m-0 pb-1",
                                            children: "Bạn l\xe0m b\xe0i kh\xe1 tốt, cố gắng ch\xfat nữa nha"
                                        }),
                                        "➤ Xem kết quả b\xean dưới xem m\xecnh sai ở đ\xe2u, ghi nhớ v\xe0 \xf4n tập lại ạ!"
                                    ]
                                }),
                                inCorrect >= total / 2 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "text-left pb-2",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                            className: "m-0 pb-1",
                                            children: "Bạn đ\xe3 ho\xe0n th\xe0nh b\xe0i kiểm tra tuy nhi\xean kết quả chưa được ưng \xfd lắm cố gắng th\xeam nhiều nh\xe9"
                                        }),
                                        "➤ Xem kết quả b\xean dưới xem m\xecnh sai ở đ\xe2u, ghi nhớ v\xe0 \xf4n tập lại ạ!"
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("table", {
                            className: "table table-lesson bordered",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tr", {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                        className: "text-dark fs-3",
                                        children: answerList
                                    })
                                })
                            })
                        })
                    ]
                })
            }),
            inCorrect < total / 2 && !disableClick && token ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        children: "Bạn đủ điểm để x\xe1c nhận qua b\xe0i nhấn n\xfat x\xe1c nhận b\xean dưới để bọn m\xecnh cập nhật tiến tr\xecnh học cho bạn nh\xe9"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: "btn btn-main-y fs-5 ps-3 pe-3",
                            disabled: disabledClick || disableClick,
                            onClick: ()=>{
                                setDisabledClick(true);
                                updateProgress();
                                setTimeout(()=>sweetalert2__WEBPACK_IMPORTED_MODULE_4___default().fire({
                                        title: 'Bạn đ\xe3 ho\xe0n th\xe0nh b\xe0i học',
                                        text: 'Ch\xfac mừng bạn đ\xe3 ho\xe0n th\xe0nh b\xe0i học, h\xe3y nghỉ ngơi thư gi\xe3n đầu \xf3c để lấy tinh thần cho c\xe1c b\xe0i học sau!',
                                        icon: 'success'
                                    }).then(()=>next_router__WEBPACK_IMPORTED_MODULE_5___default().reload()
                                    )
                                , 200);
                            },
                            children: "X\xe1c nhận"
                        })
                    })
                ]
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: disableClick && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                    children: "Bạn đang \xf4n lại b\xe0i đ\xfang kh\xf4ng? Đ\xfang rồi phải thường xuy\xean \xf4n luyện th\xec mới nhớ b\xe0i l\xe2u ạ !!!"
                })
            })
        ]
    }));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Scoresheet);


/***/ }),

/***/ 6737:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ practice)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/practice/Scoresheet.js
var Scoresheet = __webpack_require__(9575);
// EXTERNAL MODULE: ./components/apiRequest/Axios.js
var Axios = __webpack_require__(8420);
// EXTERNAL MODULE: ./utils/isMobile.js
var isMobile = __webpack_require__(9274);
// EXTERNAL MODULE: external "sweetalert2"
var external_sweetalert2_ = __webpack_require__(271);
var external_sweetalert2_default = /*#__PURE__*/__webpack_require__.n(external_sweetalert2_);
// EXTERNAL MODULE: external "universal-cookie"
var external_universal_cookie_ = __webpack_require__(6153);
var external_universal_cookie_default = /*#__PURE__*/__webpack_require__.n(external_universal_cookie_);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
var router_default = /*#__PURE__*/__webpack_require__.n(router_);
;// CONCATENATED MODULE: ./components/practice/Practice.js

/* eslint-disable @next/next/no-img-element */ 






class Pracrice extends external_react_.Component {
    constructor(props){
        super(props);
        this.state = {
            questionBank: [],
            idParam: "",
            titleParam: "",
            userAnswerList: [],
            isCorrectList: [],
            currentIndex: 0,
            userAnswer: null,
            score: 0,
            disabled: true,
            disabledOptions: false,
            option1: false,
            option2: false,
            option3: false,
            option4: false,
            endQuiz: false,
            dnTitle: 1,
            disabledCheck: true
        };
        //Bind this keyword
        this.checkAnswer = this.checkAnswer.bind(this);
        this.answerIsCorrect = this.answerIsCorrect.bind(this);
    }
    //Load the question from indexedDB when component mounts
    componentDidMount() {
        this.fetchBooks();
        this.loadQuestions();
    }
    // componentWillUnmount() {
    // }
    //Reads the question from IndexedDB and load them into the questionBank
    loadQuestions = ()=>{
        let id = this.props.idParam;
        let title = this.props.titleParam;
        this.setState({
            idParam: id,
            titleParam: title
        });
    };
    fetchBooks = ()=>{
        let id = this.props.idParam;
        (0,Axios/* default */.Z)({
            method: "get",
            url: `${this.props.lessonApi}/${id}`
        }).then((result)=>{
            this.setState({
                questionBank: result.data
            });
        //   console.log(result.data)
        }, (error)=>{
            console.log(error);
        });
    };
    // componentDidUpdate(prevProps, prevState) {
    //   }
    //Increment the currentIndex when next button is clicked
    nextQuestionHander = ()=>{
        if (this.state.dnTitle <= 2) {
            this.setState({
                dnTitle: this.state.dnTitle + 1
            });
        } else {
            this.setState({
                dnTitle: 1
            });
        }
        this.setState({
            currentIndex: this.state.currentIndex + 1,
            disabled: true,
            disabledOptions: false,
            disabledCheck: true,
            option1: false,
            option2: false,
            option3: false,
            option4: false,
            correctAnswer: '',
            userAnswer: ''
        });
    };
    //Check if UserAnser is correct 
    answerIsCorrect(userAnswer) {
        const { currentIndex , questionBank  } = this.state;
        if (userAnswer === questionBank[currentIndex].answer) {
            return true;
        } else {
            return false;
        }
    }
    //Increment score if answer is correct and enable Next Button
    checkAnswer = ()=>{
        const { score , userAnswer , questionBank , currentIndex  } = this.state;
        if (this.answerIsCorrect(userAnswer)) {
            this.setState({
                score: score + 5
            });
        }
        if (!this.answerIsCorrect(userAnswer)) {
            this.setState((prevState)=>({
                    isCorrectList: [
                        ...prevState.isCorrectList,
                        `Câu ${currentIndex + 1}: Bạn chọn ${userAnswer} || Đáp án đúng là ${questionBank[currentIndex].answer}`
                    ]
                })
            );
        }
        this.setState({
            disabledOptions: true,
            disabled: false,
            disabledCheck: true,
            correctAnswer: questionBank[currentIndex].answer
        });
        this.setState((prevState)=>({
                userAnswerList: [
                    ...prevState.userAnswerList,
                    userAnswer
                ]
            })
        );
    };
    //Set the User answer depending on which option the user clicked
    setUserAnswer = (event)=>{
        if (event.target.id === "1") {
            this.setState({
                option1: event.target.checked,
                option2: false,
                option3: false,
                option4: false,
                userAnswer: event.target.value
            });
        } else if (event.target.id === "2") {
            this.setState({
                option2: event.target.checked,
                option1: false,
                option3: false,
                option4: false,
                userAnswer: event.target.value
            });
        } else if (event.target.id === "3") {
            this.setState({
                option3: event.target.checked,
                option2: false,
                option1: false,
                option4: false,
                userAnswer: event.target.value
            });
        } else if (event.target.id === "4") {
            this.setState({
                option4: event.target.checked,
                option2: false,
                option3: false,
                option1: false,
                userAnswer: event.target.value
            });
        }
        this.setState({
            disabledCheck: false
        });
    };
    // updateProgress
    render() {
        const { currentIndex , endQuiz , questionBank , score , userAnswer , titleParam , userAnswerList , idParam  } = this.state;
        const total = questionBank.length;
        var answerList = this.state.isCorrectList.map((result, key)=>{
            return(/*#__PURE__*/ jsx_runtime_.jsx("li", {
                children: result
            }, key));
        });
        const isMobi = this.props.isMobile;
        const list = window.listExamsVideo;
        const progress = this.props.progress;
        const link = this.props.link;
        const disableClick = (Number(idParam) > 30 ? (Number(idParam) - 30) * 2 : Number(idParam) * 2) <= Number(progress);
        const cookie = new (external_universal_cookie_default())();
        const token = cookie.get("TOKEN");
        if (currentIndex <= total - 1 && endQuiz === false) {
            return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: !isMobi ? "ps-5 pe-5" : "ps-0 pe-0",
                children: [
                    idParam > 5 ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "container-exam mt-3",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "row m-0",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h4", {
                                        className: "p-0",
                                        children: [
                                            "EPS - TOPIK ",
                                            titleParam ? `${this.props.dn}: (${titleParam})` : `Bài: ${idParam}`
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "ratio ratio-21x9 p-0 border rounded",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("iframe", {
                                            src: `https://www.youtube.com/embed/${list[idParam - 1]}?rel=0&amp;showinfo=0`,
                                            controls: "0",
                                            title: "YouTube video player",
                                            frameBorder: "0",
                                            allow: "fullscreen;accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture",
                                            allowFullScreen: true
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                className: "mb-0 pb-2",
                                children: "Check Answer Zone - T\xedch đ\xe1p \xe1n"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "row border m-0 rounded p-0",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: "m-0 pt-2",
                                        disabled: true,
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h3", {
                                            children: [
                                                "C\xe2u: ",
                                                currentIndex + 1
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("fieldset", {
                                        className: "border bg-info m-0 p-0",
                                        disabled: this.state.disabledOptions,
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                            className: "m-2 p-0 pt-2 pb-2",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "inputbtn",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                id: "1",
                                                                onChange: this.setUserAnswer,
                                                                type: "radio",
                                                                name: "option",
                                                                value: "1",
                                                                checked: this.state.option1
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                                htmlFor: "1",
                                                                className: "inputBtn",
                                                                children: "1"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "checkmark"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "inputbtn",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                id: "2",
                                                                onChange: this.setUserAnswer,
                                                                type: "radio",
                                                                name: "option",
                                                                value: "2",
                                                                checked: this.state.option2
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                                htmlFor: "2",
                                                                className: "inputBtn",
                                                                children: "2"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "checkmark"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "inputbtn",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                id: "3",
                                                                onChange: this.setUserAnswer,
                                                                type: "radio",
                                                                name: "option",
                                                                value: "3",
                                                                checked: this.state.option3
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                                htmlFor: "3",
                                                                className: "inputBtn",
                                                                children: "3"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "checkmark"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "inputbtn",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                id: "4",
                                                                onChange: this.setUserAnswer,
                                                                type: "radio",
                                                                name: "option",
                                                                value: "4",
                                                                checked: this.state.option4
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                                htmlFor: "4",
                                                                className: "inputBtn",
                                                                children: "4"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "checkmark"
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "d-flex mt-2",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "m-0",
                                        children: "Bạn đ\xe3 chọn đ\xe1p \xe1n:"
                                    }),
                                    " ",
                                    userAnswer && /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "checkmark-answer m-0 ms-2 me-2",
                                            children: userAnswer
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "d-flex mt-2 mb-2",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: "btn button btn-exam me-auto",
                                        onClick: this.checkAnswer,
                                        disabled: this.state.disabledCheck,
                                        children: isMobi ? "Confirm" : "Confirm answer"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: "btn button btn-exam",
                                        onClick: this.nextQuestionHander,
                                        disabled: this.state.disabled,
                                        children: userAnswerList.length >= total ? 'Kết quả' : 'Next'
                                    })
                                ]
                            })
                        ]
                    }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "row m-0",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h4", {
                                className: "p-0",
                                children: [
                                    "\xd4n tập b\xe0i: ",
                                    idParam
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "p-0 border rounded",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                        className: "p-2 pt-4 text-center",
                                        children: "Đ\xe2y l\xe0 phần tự luyện tập c\xe1c bạn cố gắng tự ho\xe0n thiện nh\xe9. Đừng nhấn x\xe1c nhận lu\xf4n để qua b\xe0i đ\xf3 nha"
                                    }),
                                    list[idParam - 1].map((item)=>/*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            className: "mt-5",
                                            style: {
                                                width: "100%"
                                            },
                                            src: `/media/img/courses/eps-topik/1/${item}.png`,
                                            alt: ""
                                        }, item)
                                    )
                                ]
                            }),
                            !disableClick && token && /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "btn btn-main-y fs-5 ps-3 pe-3 mt-2 mb-3",
                                onClick: ()=>{
                                    this.props.updateProgress();
                                    setTimeout(()=>external_sweetalert2_default().fire({
                                            title: 'Bạn đ\xe3 ho\xe0n th\xe0nh b\xe0i học',
                                            text: 'Ch\xfac mừng bạn đ\xe3 ho\xe0n th\xe0nh b\xe0i học, h\xe3y nghỉ ngơi thư gi\xe3n đầu \xf3c để lấy tinh thần cho c\xe1c b\xe0i học sau!',
                                            icon: 'success'
                                        }).then(()=>router_default().reload()
                                        )
                                    , 200);
                                },
                                children: "X\xe1c nhận ho\xe0n th\xe0nh b\xe0i học"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {})
                ]
            }));
        } else {
            return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ jsx_runtime_.jsx(Scoresheet/* default */.Z, {
                    score: score,
                    totalQuestions: total,
                    bntitle: questionBank.dntitle,
                    answerList: answerList,
                    updateProgress: this.props.updateProgress,
                    progress: this.props.progress,
                    idParam: idParam,
                    link: link
                })
            }));
        }
    }
}
const HangeulPractice = (props)=>/*#__PURE__*/ jsx_runtime_.jsx(Pracrice, {
        ...props,
        lessonApi: "/hangeulPractice",
        isMobile: (0,isMobile/* default */.Z)("800"),
        idParam: props.idParam,
        updateProgress: props.updateProgress,
        progress: props.progress,
        link: props.link
    })
;
const ChapterPractice = (props)=>/*#__PURE__*/ jsx_runtime_.jsx(Pracrice, {
        ...props,
        lessonApi: "/lessonPracrice",
        isMobile: (0,isMobile/* default */.Z)("800"),
        idParam: props.idParam,
        updateProgress: props.updateProgress,
        progress: props.progress,
        link: props.link
    })
;
const PracticeRead = (props)=>/*#__PURE__*/ jsx_runtime_.jsx(Pracrice, {
        ...props,
        lessonApi: "/Qbank_read",
        isMobile: (0,isMobile/* default */.Z)("800"),
        dn: "Đọc",
        idParam: props.idParam,
        titleParam: props.titleParam,
        updateProgress: props.updateProgress,
        progress: props.progress,
        link: props.link
    })
;
const PracticeListen = (props)=>/*#__PURE__*/ jsx_runtime_.jsx(Pracrice, {
        ...props,
        lessonApi: "/Qbank_listen",
        isMobile: (0,isMobile/* default */.Z)("800"),
        dn: "Nghe",
        idParam: props.idParam,
        titleParam: props.titleParam,
        updateProgress: props.updateProgress,
        progress: props.progress,
        link: props.link
    })
;

;// CONCATENATED MODULE: ./components/practice/index.js



const Practice = ({ idParam , titleParam , updateProgress , progress , link  })=>{
    let chapter = link;
    if (chapter === "Hangeul") return(/*#__PURE__*/ jsx_runtime_.jsx(HangeulPractice, {
        updateProgress: updateProgress,
        progress: progress,
        idParam: idParam
    }));
    if (chapter === "Chapter1" || chapter === "Chapter2") return(/*#__PURE__*/ jsx_runtime_.jsx(ChapterPractice, {
        updateProgress: updateProgress,
        progress: progress,
        idParam: idParam
    }));
    if (chapter === "Practice-read") return(/*#__PURE__*/ jsx_runtime_.jsx(PracticeRead, {
        updateProgress: updateProgress,
        progress: progress,
        idParam: idParam,
        titleParam: titleParam
    }));
    if (chapter === "Practice-listen") return(/*#__PURE__*/ jsx_runtime_.jsx(PracticeListen, {
        updateProgress: updateProgress,
        progress: progress,
        idParam: idParam,
        titleParam: titleParam
    }));
};
/* harmony default export */ const practice = (Practice);


/***/ })

};
;