"use strict";
exports.id = 7374;
exports.ids = [7374];
exports.modules = {

/***/ 7374:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ auth_Auth)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "universal-cookie"
var external_universal_cookie_ = __webpack_require__(6153);
var external_universal_cookie_default = /*#__PURE__*/__webpack_require__.n(external_universal_cookie_);
// EXTERNAL MODULE: ./components/apiRequest/Axios.js
var Axios = __webpack_require__(8420);
;// CONCATENATED MODULE: ./components/auth/Login.js




const cookies = new (external_universal_cookie_default())();
function Login() {
    // initial state
    const { 0: username , 1: setUsername  } = (0,external_react_.useState)("");
    const { 0: password , 1: setPassword  } = (0,external_react_.useState)("");
    const { 0: login , 1: setLogin  } = (0,external_react_.useState)(false);
    const { 0: message , 1: setMessage  } = (0,external_react_.useState)();
    const { 0: disabled , 1: setDisabled  } = (0,external_react_.useState)(false);
    const { 0: countErr , 1: setcountErr  } = (0,external_react_.useState)(0);
    const { 0: err , 1: setErr  } = (0,external_react_.useState)(false);
    const { 0: seconds , 1: setSeconds  } = (0,external_react_.useState)(null);
    // countDown
    (0,external_react_.useEffect)(()=>{
        if (seconds > 0) {
            setTimeout(()=>setSeconds((prev)=>prev - 1
                )
            , 1000);
            setMessage(`Bạn nhập sai mật khẩu nhiều lần nên tạm thời đã bị khóa đăng nhập,
          bạn đợi sau ${seconds} sau hệ thống sẽ trả lại quyền đăng nhập cho bạn`);
        } else if (seconds === 0) {
            setMessage("");
            localStorage.setItem('items', JSON.stringify(0));
            setcountErr(0);
            setItems([]);
        }
    }, [
        seconds
    ]);
    // get localStorage var
    const { 0: items1 , 1: setItems  } = (0,external_react_.useState)([]);
    (0,external_react_.useEffect)(()=>{
        const items = JSON.parse(localStorage.getItem('items'));
        if (items) {
            setItems(items);
        }
    }, [
        items1
    ]);
    //  
    (0,external_react_.useEffect)(()=>{
        if (items1 >= 4 || countErr > 4) {
            setDisabled(true);
            setSeconds(30);
        } else {
            setDisabled(false);
        }
    }, [
        items1,
        countErr
    ]);
    function ChangeHandle() {
        if (err) {
            setcountErr((prev)=>prev + 1
            );
            setTimeout(()=>{
                localStorage.setItem('items', JSON.stringify(countErr));
                setErr(false);
            }, 100);
        }
    }
    const handleSubmit = (e)=>{
        // prevent the form from refreshing the whole page
        e.preventDefault();
        // set configurations
        const configuration = {
            method: "post",
            url: "/login",
            data: {
                username,
                password
            }
        };
        // make the API call
        (0,Axios/* default */.Z)(configuration).then((result)=>{
            // set the cookie
            cookies.set("TOKEN", result.data.token, {
                path: "/"
            });
            // redirect user to the auth page
            setMessage(result.data.msg);
            setLogin(true);
            setTimeout(()=>window.location.reload()
            , 1000);
        }).catch((error)=>{
            if (error) {
                setMessage(error.response.data.msg);
                setErr(error.response.data.countErr);
            }
        });
        ChangeHandle();
    };
    return(/*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container justify-content-center",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "row d-flex justify-content-center",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                    className: "d-flex flex-column col-md-6",
                    onSubmit: (e)=>handleSubmit(e)
                    ,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            children: "Login"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                            htmlFor: "Username",
                            className: "mt-3",
                            children: [
                                "Username:",
                                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                    name: "username",
                                    id: "Username",
                                    type: "text",
                                    className: "form-control",
                                    value: username,
                                    onChange: (e)=>setUsername(e.target.value)
                                    ,
                                    required: true
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                            htmlFor: "password",
                            className: "mt-3",
                            children: [
                                "Password:",
                                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                    name: "password",
                                    id: "password",
                                    type: "password",
                                    className: "form-control",
                                    value: password,
                                    onChange: (e)=>setPassword(e.target.value)
                                    ,
                                    required: true
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            className: "mt-3 btn bg-success text-light",
                            type: "submit",
                            disabled: disabled,
                            onClick: (e)=>handleSubmit(e)
                            ,
                            children: "Login"
                        }),
                        login ? /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "text-success mt-2",
                            children: message
                        }) : /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "text-danger mt-2",
                            children: message
                        })
                    ]
                })
            })
        })
    }));
};

;// CONCATENATED MODULE: ./components/auth/Register.js



function Register() {
    // initial state
    const { 0: email , 1: setEmail  } = (0,external_react_.useState)("");
    const { 0: username , 1: setUsername  } = (0,external_react_.useState)("");
    const { 0: name , 1: setName  } = (0,external_react_.useState)("");
    const { 0: sex , 1: setsex  } = (0,external_react_.useState)("male");
    const { 0: password , 1: setPassword  } = (0,external_react_.useState)("");
    const { 0: password_repeat , 1: setPassword_repeat  } = (0,external_react_.useState)("");
    const { 0: register , 1: setRegister  } = (0,external_react_.useState)(false);
    const { 0: message , 1: setMessage  } = (0,external_react_.useState)();
    const handleSubmit = (e)=>{
        // prevent the form from refreshing the whole page
        e.preventDefault();
        // set configurations
        const configuration = {
            method: "post",
            url: "/sign-up",
            data: {
                name,
                username,
                email,
                sex,
                password,
                password_repeat
            }
        };
        // make the API call
        (0,Axios/* default */.Z)(configuration).then((result)=>{
            setRegister(true);
            setMessage(result.data.msg);
        }).catch(function(error) {
            if (error.response) {
                setMessage(error.response.data.msg);
            }
        });
    };
    return(/*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container justify-content-center",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "row d-flex justify-content-center",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                    className: "d-flex flex-column col-md-6",
                    onSubmit: (e)=>handleSubmit(e)
                    ,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            children: "Register"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                            htmlFor: "name",
                            className: "mt-3",
                            children: [
                                "Name:",
                                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                    name: "name",
                                    id: "name",
                                    type: "text",
                                    className: "form-control",
                                    value: name,
                                    onChange: (e)=>setName(e.target.value)
                                    ,
                                    placeholder: "Enter Your Name",
                                    required: true
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                            htmlFor: "sex",
                            className: "mt-3",
                            children: [
                                "Giới t\xednh:",
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("select", {
                                    name: "sex",
                                    id: "sex",
                                    type: "text",
                                    className: "form-control",
                                    value: sex,
                                    onChange: (e)=>setsex(e.target.value)
                                    ,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                            children: "male"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                            children: "female"
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                            htmlFor: "username",
                            className: "mt-3",
                            children: [
                                "Username:",
                                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                    name: "username",
                                    id: "username",
                                    type: "text",
                                    className: "form-control",
                                    value: username,
                                    onChange: (e)=>setUsername(e.target.value)
                                    ,
                                    placeholder: "Kh\xf4ng bao gồm k\xfd tự đặc biết v\xe0 dấu c\xe1ch",
                                    required: true
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                            htmlFor: "email",
                            className: "mt-3",
                            children: [
                                "Email:",
                                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                    name: "email",
                                    id: "email",
                                    type: "email",
                                    className: "form-control",
                                    value: email,
                                    onChange: (e)=>setEmail(e.target.value)
                                    ,
                                    placeholder: "Enter email",
                                    required: true
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                            htmlFor: "password",
                            className: "mt-3",
                            children: [
                                "Password:",
                                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                    name: "password",
                                    id: "password",
                                    type: "password",
                                    className: "form-control",
                                    value: password,
                                    onChange: (e)=>setPassword(e.target.value)
                                    ,
                                    placeholder: "Password",
                                    required: true
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                            htmlFor: "password_repeat",
                            className: "mt-3",
                            children: [
                                "Password Confirm:",
                                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                    name: "password_repeat",
                                    id: "password_repeat",
                                    type: "password",
                                    className: "form-control",
                                    value: password_repeat,
                                    onChange: (e)=>setPassword_repeat(e.target.value)
                                    ,
                                    placeholder: "Nhập lại Password",
                                    required: true
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            className: "mt-3 btn bg-success text-light",
                            type: "submit",
                            children: "Register"
                        }),
                        register ? /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "text-success mt-2",
                            children: message
                        }) : /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "text-danger mt-2",
                            children: message
                        })
                    ]
                })
            })
        })
    }));
};

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
var router_default = /*#__PURE__*/__webpack_require__.n(router_);
// EXTERNAL MODULE: external "jwt-decode"
var external_jwt_decode_ = __webpack_require__(5567);
var external_jwt_decode_default = /*#__PURE__*/__webpack_require__.n(external_jwt_decode_);
;// CONCATENATED MODULE: ./components/auth/AuthDetail.js

/* eslint-disable @next/next/no-img-element */ 





const AuthDetail = ()=>{
    const cookies = new (external_universal_cookie_default())();
    const token = cookies.get('TOKEN');
    const [decoded, setDecoded] = external_react_default().useState([]);
    const [myCourse, setmyCourse] = external_react_default().useState([]);
    const [findUserId, setfindUserId] = external_react_default().useState([]);
    external_react_default().useEffect(()=>{
        if (token) {
            setDecoded(external_jwt_decode_default()(token));
        }
    }, [
        token
    ]) // eslint-disable-line react-hooks/exhaustive-deps
    ;
    external_react_default().useEffect(()=>{
        if (decoded) {
            (0,Axios/* default */.Z)({
                method: "GET",
                url: "/progress"
            }).then((rep)=>setfindUserId(rep.data.filter((d)=>d.userId == decoded.userId
                ))
            );
            (0,Axios/* default */.Z)({
                method: "GET",
                url: "/courseviews"
            }).then((rep)=>setmyCourse(rep.data)
            );
        }
    }, [
        decoded
    ]);
    const [authDetail, setAuthDetail] = external_react_default().useState([]);
    external_react_default().useEffect(()=>{
        if (myCourse.length && findUserId.length) {
            setAuthDetail(findUserId.map((item)=>{
                const x = myCourse.find((d)=>d.id == item.course_id
                );
                return x;
            }));
        }
    }, [
        myCourse,
        findUserId
    ]);
    return(/*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "dropdown ms-lg-0 mt-1",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                    className: "btn avatar avatar-sm p-0",
                    href: "#",
                    id: "profileDropdown",
                    role: "button",
                    "data-bs-auto-close": "outside",
                    "data-bs-display": "static",
                    "data-bs-toggle": "dropdown",
                    "aria-expanded": "false",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        width: 36,
                        className: "avatar-img rounded-circle mt-0",
                        src: `/media/img/avatars/${decoded ? decoded.sex : "user"}.png`,
                        alt: "avatar"
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                    className: "dropdown-menu dropdown-menu-custom dropdown-menu-end shadow pt-3 mt-2",
                    "aria-labelledby": "profileDropdown",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "d-flex align-items-center px-2",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "avatar me-3",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                width: 50,
                                                className: "avatar-img rounded-circle shadow",
                                                src: `/media/img/avatars/${decoded ? decoded.sex : "user"}.png`,
                                                alt: "avatar"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                            children: decoded && decoded.name
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                    className: "dropdown-divider"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "px-2 text-secondary",
                                    children: "Hạng th\xe0nh vi\xean: "
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: decoded && decoded.role
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: "/Course",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    className: "px-2 btn text-secondary",
                                    children: "Ghi danh kh\xf3a học"
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "dropdown",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: "btn dropdown-toggle nav-link text-secondary p-0 ps-2",
                                        id: "dropdownMyCourse",
                                        "data-bs-toggle": "dropdown",
                                        "aria-expanded": "false",
                                        children: "Kh\xf3a học của t\xf4i"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                        className: "dropdown-menu m-0 p-0 pt-2",
                                        style: {
                                            minWidth: "17.9rem"
                                        },
                                        "aria-labelledby": "dropdownMyCourse",
                                        children: authDetail.length > 0 ? authDetail.map((d, i)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                className: "ps-2 pe-2 pb-2",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                    href: d.link,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        className: "btn border btn-main-y",
                                                        style: {
                                                            width: "100%"
                                                        },
                                                        children: d.title
                                                    })
                                                })
                                            }, i)
                                        ) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    className: "ps-2 pe-2 pb-2",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        className: "btn border btn-main-y",
                                                        style: {
                                                            width: "100%"
                                                        },
                                                        children: "Chưa c\xf3 kh\xf3a học n\xe0o"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    className: "ps-2 pe-2 pb-2",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                        href: "/Course",
                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                            className: "btn border btn-main-y",
                                                            style: {
                                                                width: "100%"
                                                            },
                                                            children: [
                                                                "Đăng k\xfd ngay ",
                                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                    className: "fa fa-angle-double-right",
                                                                    "aria-hidden": "true"
                                                                })
                                                            ]
                                                        })
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                className: "dropdown-divider"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "modeswitch-wrap d-flex",
                                id: "darkModeSwitch",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                    className: "btn border ms-2",
                                    onClick: ()=>{
                                        cookies.remove("TOKEN", {
                                            path: "/"
                                        });
                                        router_default().reload();
                                    },
                                    children: [
                                        "Logout \xa0\xa0",
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "fa fa-sign-out",
                                            "aria-hidden": "true"
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                })
            ]
        })
    }));
};
/* harmony default export */ const auth_AuthDetail = (AuthDetail);

;// CONCATENATED MODULE: ./components/auth/Auth.js

/* eslint-disable @next/next/no-img-element */ 




const Auth = ()=>{
    const { 0: token , 1: settoken  } = (0,external_react_.useState)(null);
    const cookies = new (external_universal_cookie_default())();
    const { 0: login , 1: setLogin  } = (0,external_react_.useState)(true);
    const { 0: showForm , 1: setshowForm  } = (0,external_react_.useState)(false);
    (0,external_react_.useEffect)(()=>{
        settoken(cookies.get('TOKEN'));
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    // loginStatus
    function loginStatus() {
        setLogin(!login);
    }
    // showForm Login & Register
    function showFormHandle() {
        setshowForm(!showForm);
    }
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "ms-auto pe-2",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            children: !token ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: `text-primary btn ms-auto m-0 fs-6 pt-2`,
                        onClick: showFormHandle,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                className: "fa fa-sign-in",
                                "aria-hidden": "true"
                            }),
                            " Login"
                        ]
                    }),
                    showForm && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "form-login bg-light bg-opacity-90 pt-4 d-fixed",
                        children: [
                            login ? /*#__PURE__*/ jsx_runtime_.jsx(Login, {}) : /*#__PURE__*/ jsx_runtime_.jsx(Register, {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "container justify-content-center mb-5",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "row d-flex justify-content-center",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "d-flex flex-column col-md-6",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "d-flex align-middle",
                                            children: login ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        children: "Bạn chưa c\xf3 t\xe0i khoản?"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "text-primary btn ms-3 p-0",
                                                        onClick: loginStatus,
                                                        children: "Đăng k\xfd"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "text-danger btn ms-auto p-0",
                                                        onClick: ()=>{
                                                            showFormHandle();
                                                            setLogin(true);
                                                        },
                                                        children: "Close"
                                                    })
                                                ]
                                            }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        children: "Bạn đ\xe3 c\xf3 t\xe0i khoản?"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "text-primary btn ms-3 p-0",
                                                        onClick: loginStatus,
                                                        children: "Đăng nhập"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "text-danger btn ms-auto p-0 pe-2",
                                                        onClick: ()=>{
                                                            showFormHandle();
                                                            setLogin(true);
                                                        },
                                                        children: "Close"
                                                    })
                                                ]
                                            })
                                        })
                                    })
                                })
                            })
                        ]
                    })
                ]
            }) : /*#__PURE__*/ jsx_runtime_.jsx(auth_AuthDetail, {})
        })
    }));
};
/* harmony default export */ const auth_Auth = (Auth);


/***/ })

};
;