"use strict";
exports.id = 9807;
exports.ids = [9807];
exports.modules = {

/***/ 9807:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ courses_Lesson)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "jwt-decode"
var external_jwt_decode_ = __webpack_require__(5567);
var external_jwt_decode_default = /*#__PURE__*/__webpack_require__.n(external_jwt_decode_);
// EXTERNAL MODULE: ./components/apiRequest/Axios.js
var Axios = __webpack_require__(8420);
// EXTERNAL MODULE: ./utils/youtube/Player.js
var Player = __webpack_require__(3898);
// EXTERNAL MODULE: ./components/courses/ProgressBar.js
var ProgressBar = __webpack_require__(5243);
;// CONCATENATED MODULE: ./components/courses/LessonMenu.js

/* eslint-disable @next/next/no-img-element */ 

const LessonMenu = ({ title , link , lessonId , showMenu , token , listLesson , partParam , progress  })=>{
    const [progressed, setProgressed] = external_react_default().useState('');
    external_react_default().useEffect(()=>{
        if (progress != 0) {
            setProgressed(progress);
        }
    }, [
        progress
    ]);
    const disableClick = (lesson_id)=>{
        if (progressed !== '' && token) var finished = (lesson_id > 30 ? lesson_id - 30 : lesson_id) * 2 <= Number(progressed);
        var progressing = (lesson_id > 30 ? lesson_id - 30 : lesson_id) * 2 === Number(progressed) + 2;
        var disabledProgress = (lesson_id > 30 ? lesson_id - 30 : lesson_id) * 2 > Number(progressed) + 2;
        return {
            progressing,
            finished,
            disabledProgress
        };
    };
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `col-xl-3 p-0 accordion-col ${showMenu ? "show_col" : "hide_col"}`,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                style: {
                    paddingLeft: "2px"
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                        className: "mb-2 border-bottom pt-2 pb-2 ps-3 text-logo-b font-monospace",
                        children: title
                    }),
                    token && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "pb-3 ps-3 pe-3",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                className: "text-logo-y",
                                children: "Tiến tr\xecnh học"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(ProgressBar/* default */.Z, {
                                bgcolor: "#ff8c00",
                                progress: progressed !== '' ? progressed : '0',
                                height: 18
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "accordion accordion-flush bg-light",
                id: "accordionFlushExample",
                children: listLesson && listLesson.map((item)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "accordion-item",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                className: "accordion-header",
                                id: `flush-heading${item.id}`,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    className: `accordion-button ${item.id != lessonId && 'collapsed'} ${token && (disableClick(item.id).progressing || disableClick(item.id).finished) ? disableClick(item.id).finished ? 'text-success' : 'text-info' : 'text-secondary'}`,
                                    disabled: token ? disableClick(item.id).disabledProgress : false,
                                    type: "button",
                                    "data-bs-toggle": "collapse",
                                    "data-bs-target": `#flush-collapse${item.id}`,
                                    "aria-expanded": "false",
                                    "aria-controls": `flush-collapse${item.id}`,
                                    children: item.title
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                id: `flush-collapse${item.id}`,
                                className: `accordion-collapse collapse ${lessonId === item.id && 'show'}`,
                                "aria-labelledby": `flush-heading${item.id}`,
                                "data-bs-parent": "#accordionFlushExample",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "accordion-body list-unstyled",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                            className: "d-flex",
                                            href: `/Course/${link}/Lesson=${item.id}-1`,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                    className: "ms-3 me-3 mb-1",
                                                    width: 50,
                                                    src: "/media/img/mui_ten_r.png",
                                                    alt: ""
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h5", {
                                                    className: `${lessonId === item.id && partParam === '1' && 'text-light'}`,
                                                    children: [
                                                        "Tiết 1 ",
                                                        lessonId === item.id && partParam === '1' && /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                            className: "ms-3 mb-1",
                                                            width: 20,
                                                            src: "/media/img/loadding1.svg",
                                                            alt: ""
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                            className: "m-0 p-0 pb-2 mt-3 ms-3 me-3 border-bottom",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                children: "Nội dung tiết học"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "border rounded-3 m-3 p-3",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                                className: "m-0 p-0 list-unstyled",
                                                dangerouslySetInnerHTML: {
                                                    __html: item.part1
                                                }
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                            className: "d-flex",
                                            href: `/Course/${link}/Lesson=${item.id}-2`,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                    className: "ms-3 me-3",
                                                    width: 50,
                                                    src: "/media/img/mui_ten_r.png",
                                                    alt: ""
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h5", {
                                                    className: `${lessonId === item.id && partParam === '2' && 'text-light'}`,
                                                    children: [
                                                        "Tiết 2 ",
                                                        lessonId === item.id && partParam === '2' && /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                            className: "ms-3 mb-1",
                                                            width: 20,
                                                            src: "/media/img/loadding1.svg",
                                                            alt: ""
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                            className: "m-0 p-0 pb-2 mt-3 ms-3 me-3 border-bottom",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                children: "Nội dung tiết học"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "border rounded-3 m-3 p-3",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                                className: "m-0 p-0 list-unstyled",
                                                dangerouslySetInnerHTML: {
                                                    __html: item.part2
                                                }
                                            })
                                        })
                                    ]
                                })
                            })
                        ]
                    }, item.id)
                )
            })
        ]
    }));
};
/* harmony default export */ const courses_LessonMenu = (LessonMenu);

// EXTERNAL MODULE: ./components/notes/Note.js + 1 modules
var Note = __webpack_require__(2117);
;// CONCATENATED MODULE: ./components/seachDic/SeachDic.js



const SeachDic = ({ datas  })=>{
    const { 0: query , 1: setQuery  } = (0,external_react_.useState)('');
    const { 0: result , 1: setResult  } = (0,external_react_.useState)([]);
    const { 0: newquery , 1: setNewquery  } = (0,external_react_.useState)('');
    const { 0: newData , 1: setnewData  } = (0,external_react_.useState)('');
    const ref = (0,external_react_.useRef)();
    (0,external_react_.useEffect)(()=>{
        let componentDidMount = true;
        if (datas && componentDidMount) setnewData(datas.find((lesson)=>lesson.question === query
        ));
        return ()=>componentDidMount = false
        ;
    }, [
        datas,
        query
    ]);
    // This function is triggered when the Search buttion is clicked
    const search = ()=>{
        setNewquery(query);
        if (!newData) {
            setResult(/*#__PURE__*/ jsx_runtime_.jsx("h2", {
                className: "mt-2",
                children: "Từ bạn nhập kh\xf4ng đ\xfang"
            }));
        } else {
            setResult(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "search-result",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "text-light pt-3 pb-3",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("table", {
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tbody", {
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                        className: "border-0",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "p-2 border-0 text-start",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        children: "Từ H\xe0n:"
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "p-2 border-0 text-start",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "batangche",
                                                        children: newData.question
                                                    })
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                        className: "border-0",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "p-2 border-0 text-start",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        children: "Nghĩa Việt:"
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "p-2 border-0 text-start",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        children: newData.answer
                                                    })
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        })
                    }, newData.id),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "text-light pb-3 pt-3 ps-2 border-top border-warning",
                        children: [
                            "Ghi ch\xfa: ",
                            newData.description
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx("audio", {
                            src: `/media/audio/${newData.audio}`,
                            width: "750",
                            height: "500",
                            controls: true,
                            controlsList: "nodownload"
                        })
                    })
                ]
            }));
        }
    };
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "bg-secondary rounded-3 p-3 mb-4",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        ref: ref,
                        value: query,
                        onChange: (e)=>setQuery(e.target.value)
                        ,
                        placeholder: "Tra từ vựng",
                        className: "input",
                        onKeyDown: (e)=>{
                            if (e.code === 'Enter' || e.code === 'NumpadEnter') {
                                search();
                                if (newData) {
                                    setTimeout(()=>setQuery('')
                                    , 10);
                                }
                            }
                        }
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        className: "text-light",
                        type: "submit",
                        onClick: ()=>{
                            search();
                            if (newData) {
                                setQuery('');
                            }
                            ref.current.focus();
                        },
                        children: "Search"
                    })
                ]
            }),
            newquery ? result : /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                className: "mt-2 text-light",
                children: "Mời bạn nhập từ để t\xecm kiếm"
            })
        ]
    }));
};
/* harmony default export */ const seachDic_SeachDic = (SeachDic);

// EXTERNAL MODULE: ./utils/isMobile.js
var utils_isMobile = __webpack_require__(9274);
// EXTERNAL MODULE: ./utils/share/ShareSocial.js
var ShareSocial = __webpack_require__(2088);
// EXTERNAL MODULE: ./utils/duration.js
var utils_duration = __webpack_require__(1394);
// EXTERNAL MODULE: ./components/practice/Prac1.js
var Prac1 = __webpack_require__(9692);
;// CONCATENATED MODULE: ./components/courses/Lesson.js












const Lesson = ({ link , lesson_ssr , listLesson , showMenu , token , partParam , idParam , progresses , dataDic , questions  })=>{
    const isMobile800 = (0,utils_isMobile/* default */.Z)('800');
    const lesson = lesson_ssr[0];
    // cookie
    const [userId, setuserId] = external_react_default().useState(null);
    const [idprogress, setidprogress] = external_react_default().useState(0);
    const [progress, setprogress] = external_react_default().useState(0);
    external_react_default().useEffect(()=>{
        let componentUnmount = true;
        if (progresses && componentUnmount) {
            setidprogress(progresses.id);
            setprogress(progresses.progress);
        }
        return ()=>componentUnmount = false
        ;
    }, [
        progresses
    ]);
    external_react_default().useEffect(()=>{
        let componentUnmount = true;
        if (token && componentUnmount) {
            setuserId(external_jwt_decode_default()(token).userId);
        }
        return ()=>componentUnmount = false
        ;
    }, [
        token
    ]);
    // get data
    const [newData, setNewData] = external_react_default().useState();
    const isMobile = (0,utils_isMobile/* default */.Z)('1200');
    const [videoUrl, setVideoUrl] = external_react_default().useState();
    const [btnId, setBtnId] = external_react_default().useState('1');
    // params
    const part = partParam;
    const id = idParam;
    // get progress
    const [idApi, setIdApi] = external_react_default().useState(null);
    const disableClick = (lesson_id)=>{
        if (progress !== '' && token) var finished = (lesson_id > 30 ? lesson_id - 30 : lesson_id) * 2 <= Number(progress);
        var progressing = (lesson_id > 30 ? lesson_id - 30 : lesson_id) * 2 === Number(progress) + 2;
        var disabledProgress = (lesson_id > 30 ? lesson_id - 30 : lesson_id) * 2 > Number(progress) + 2;
        return {
            progressing,
            finished,
            disabledProgress
        };
    };
    // checkElapsedTime of youtube Frame
    const [pause, setpause] = external_react_default().useState(false);
    const [duration, setDuration] = external_react_default().useState("");
    const [currentTime, setCurrentTime] = external_react_default().useState("");
    const [playingSeconds, setPlayingSeconds] = external_react_default().useState("");
    // % Played of video
    const percentPlayed = playingSeconds / duration;
    // 
    const { mm , ss  } = (0,utils_duration/* TimeCalculator */.x)(Number(playingSeconds));
    const { mm: mmdura , ss: ssdura  } = (0,utils_duration/* TimeCalculator */.x)(Number(duration));
    // setStartAt props
    const [startAt, setStartAt] = external_react_default().useState('');
    // updateProgress
    const updateProgress = ()=>{
        if (idprogress != 0) (0,Axios/* default */.Z)({
            method: 'PUT',
            url: `/progress/${idprogress}`,
            data: {
                progress: progress + 2
            }
        });
    };
    // share social
    const [showShare, setShowShare] = external_react_default().useState(false);
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "row m-0",
        children: lesson ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "col-xl-9 p-0 m-0 border-1 border-end border-warning",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "ratio ratio-16x9",
                            children: token ? idprogress === 0 ? /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                className: "text-logo-b text-center pt-5",
                                children: "Bạn chưa ghi danh v\xe0o kh\xf3a học ạ. Nếu muốn học m\xe0 kh\xf4ng cần ghi danh bạn c\xf3 chỉ cần đăng xuất khỏi hệ thống"
                            }) : disableClick(lesson.id).disabledProgress ? /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                className: "text-logo-b text-center pt-5",
                                children: "Bạn phải ho\xe0n th\xe0nh b\xe0i học trước rồi quay lại b\xe0i học n\xe0y nh\xe9! Sorry"
                            }) : /*#__PURE__*/ jsx_runtime_.jsx(Player/* default */.Z, {
                                videoId: videoUrl ? videoUrl : lesson.videoURL1,
                                startAt: startAt,
                                playing: pause,
                                setplaying: setpause,
                                setDuration: setDuration,
                                setPlayedSeconds: setCurrentTime,
                                setPlayingSeconds: setPlayingSeconds
                            }) : /*#__PURE__*/ jsx_runtime_.jsx(Player/* default */.Z, {
                                videoId: videoUrl ? videoUrl : lesson.videoURL1,
                                startAt: startAt,
                                playing: pause,
                                setplaying: setpause,
                                setDuration: setDuration,
                                setPlayedSeconds: setCurrentTime,
                                setPlayingSeconds: setPlayingSeconds
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                            className: `nav nav-tabs pt-1 pb-1 justify-content-center player-control ${!isMobile800 && 'ps-5'}`,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: "me-3",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: "btn",
                                        onClick: ()=>setpause(!pause)
                                        ,
                                        children: pause ? /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "fa fa-pause text-light",
                                            "aria-hidden": "true"
                                        }) : /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "fa fa-play text-light",
                                            "aria-hidden": "true"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    className: "btn text-light",
                                    children: [
                                        "Thời gian ",
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                            children: [
                                                mm,
                                                " : ",
                                                ss
                                            ]
                                        }),
                                        " / ",
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                            children: [
                                                mmdura,
                                                " : ",
                                                ssdura
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                            className: `nav nav-tabs pt-2 ${!isMobile800 && 'ps-5'}`,
                            style: {
                                fontSize: "15px"
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: "nav-item item-action m-0 p-0",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        id: "btn1",
                                        onClick: ()=>setBtnId('1')
                                        ,
                                        className: `nav-link p-2 ${btnId === "1" && "active"}`,
                                        children: "Hỏi đ\xe1p"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: "nav-item item-action",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        id: "btn2",
                                        onClick: ()=>setBtnId('2')
                                        ,
                                        className: `nav-link p-2 ${btnId === "2" && "active"}`,
                                        children: "Từ vựng"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: "nav-item item-action",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        id: "btn3",
                                        onClick: ()=>setBtnId('3')
                                        ,
                                        className: `nav-link p-2 ${btnId === "3" && "active"}`,
                                        disabled: token && progress < Number(id) * 2 ? percentPlayed < 0.9 : false,
                                        children: "B\xe0i tập"
                                    })
                                }),
                                token && /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: "nav-item item-action ms-0",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        id: "btn4",
                                        onClick: ()=>setBtnId('4')
                                        ,
                                        className: `nav-link p-2 ${btnId === "4" && "active"}`,
                                        children: "Ghi ch\xfa"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: `nav-item item-action pt-2 ms-auto ${isMobile800 ? 'm-0 ps-0 pe-0' : 'ps-5 pe-5'}`,
                                    onClick: ()=>setShowShare(!showShare)
                                    ,
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                        className: "pe-3",
                                        style: {
                                            cursor: 'pointer'
                                        },
                                        children: [
                                            !isMobile800 && 'Share',
                                            "\xa0",
                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "fa fa-share-alt text-logo-b",
                                                "aria-hidden": "true"
                                            })
                                        ]
                                    })
                                })
                            ]
                        }),
                        showShare && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: isMobile800 ? 'm-0 ps-0 pe-0' : 'ps-5 pe-5',
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "p-3 m-0 mt-2",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "m-0 bg-secondary bg-opacity-25 rounded pt-3 pb-3 text-center",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(ShareSocial/* default */.Z, {
                                        shareUrl: link,
                                        title: "Kh\xf3a học - "
                                    })
                                })
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "p-3 mt-1",
                            children: [
                                btnId === "2" && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: isMobile800 ? 'm-0 ps-0 pe-0' : 'ps-5 pe-5',
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(seachDic_SeachDic, {
                                        datas: dataDic
                                    })
                                }),
                                btnId === "3" && (token ? !disableClick(lesson.id).disabledProgress && idprogress !== null && /*#__PURE__*/ jsx_runtime_.jsx(Prac1/* default */.Z, {
                                    questions: questions
                                }) : /*#__PURE__*/ jsx_runtime_.jsx(Prac1/* default */.Z, {
                                    questions: questions
                                })),
                                token && btnId === "4" && /*#__PURE__*/ jsx_runtime_.jsx(Note/* default */.Z, {
                                    urlApi: "notes",
                                    userId: userId,
                                    lessonId: lesson.id,
                                    currentTime: currentTime,
                                    setStartAt: setStartAt,
                                    setplaying: setpause
                                })
                            ]
                        })
                    ]
                }),
                lesson ? /*#__PURE__*/ jsx_runtime_.jsx(courses_LessonMenu, {
                    title: lesson.title,
                    link: link,
                    lessonId: lesson.id,
                    showMenu: showMenu,
                    token: token,
                    listLesson: listLesson,
                    partParam: partParam,
                    progress: progress
                }) : /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                    children: "Notfoud"
                })
            ]
        }) : /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
            children: /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                children: "Notfoud"
            })
        })
    }));
};
/* harmony default export */ const courses_Lesson = (Lesson);


/***/ })

};
;