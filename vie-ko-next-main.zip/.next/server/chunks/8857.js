exports.id = 8857;
exports.ids = [8857];
exports.modules = {

/***/ 4814:
/***/ ((module) => {

// Exports
module.exports = {
	"navbar": "header_navbar__dOxSn",
	"navbar__menu": "header_navbar__menu__rx5Hb",
	"navbar__user": "header_navbar__user___1nT_"
};


/***/ }),

/***/ 8857:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ DefaultLayout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "@mui/icons-material/MenuTwoTone"
var MenuTwoTone_ = __webpack_require__(984);
var MenuTwoTone_default = /*#__PURE__*/__webpack_require__.n(MenuTwoTone_);
// EXTERNAL MODULE: external "@mui/icons-material/Close"
var Close_ = __webpack_require__(4173);
var Close_default = /*#__PURE__*/__webpack_require__.n(Close_);
// EXTERNAL MODULE: external "next-themes"
var external_next_themes_ = __webpack_require__(1162);
// EXTERNAL MODULE: external "@mui/icons-material/Nightlight"
var Nightlight_ = __webpack_require__(9476);
var Nightlight_default = /*#__PURE__*/__webpack_require__.n(Nightlight_);
// EXTERNAL MODULE: external "@mui/icons-material/LightMode"
var LightMode_ = __webpack_require__(3684);
var LightMode_default = /*#__PURE__*/__webpack_require__.n(LightMode_);
;// CONCATENATED MODULE: ./components/header/Switcher.js





function ThemeSwitcher() {
    const [themeswitch, setThemeswitch] = external_react_.useState('');
    const { theme , setTheme  } = (0,external_next_themes_.useTheme)();
    external_react_.useEffect(()=>{
        setThemeswitch(theme);
    }, [
        theme
    ]);
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: `switch ${themeswitch === "dark" ? 'switchdark' : 'switchlight'} pt-1`,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
            htmlFor: "switcher",
            onClick: ()=>{
                if (theme === "dark") {
                    setTheme('light');
                } else {
                    setTheme('dark');
                }
            },
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "icon one",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((LightMode_default()), {})
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "icon two",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((Nightlight_default()), {})
                })
            ]
        })
    }));
};

;// CONCATENATED MODULE: ./components/header/header.data.js
// eslint-disable-next-line import/no-anonymous-default-export
/* harmony default export */ const header_data = ({
    home: {
        path: '/',
        label: 'Home'
    },
    study: {
        main: {
            path: '/#main',
            label: 'Học tập'
        },
        sub: [
            {
                path: '/Download',
                label: 'T\xe0i liệu'
            },
            {
                path: '/Course',
                label: 'Kh\xf3a học'
            },
            {
                path: '/Exam',
                label: 'L\xe0m đề thi'
            },
            {
                path: '/Vocabulary',
                label: 'Game gh\xe9p từ mới'
            }
        ]
    },
    epsinfo: {
        main: {
            path: '/Epsinfo',
            label: 'Th\xf4ng tin EPS'
        },
        sub: [
            {
                path: '/Epsinfo/lichthi-ngaythi',
                label: 'Lịch thi - Ng\xe0y thi'
            },
            {
                path: '/Epsinfo/Gioi-thieu-chuong-trinh-EPS',
                label: 'Giới thiệu chương tr\xecnh'
            },
            {
                path: '/Epsinfo/Dieu-kien-tham-gia',
                label: 'Quy định, điều kiện tham gia'
            },
            {
                path: '/Epsinfo/Quyen-loi-va-nghia-vu-cua-nguoi-lao-dong',
                label: 'Quyền lợi, nghĩa vụ'
            },
            {
                path: '/Epsinfo/Quy-trinh-thuc-hien-chuong-trinh-EPS',
                label: 'Quy tr\xecnh thực hiện'
            },
            {
                path: '/Epsinfo/Cac-quy-dinh-phap-luat-cua-Han-Quoc',
                label: 'Quy định ph\xe1p Luật H\xe0n Quốc'
            },
            {
                path: '/Epsinfo/Thu-tuc-ve-nuoc',
                label: 'Thủ tục về nước'
            },
            {
                path: '/Epsinfo/Bieu-mau-ho-so-chuong-trinh-EPS',
                label: 'Tải Biểu mẫu-Hồ sơ'
            },
            {
                path: '/Epsinfo',
                label: 'Xem tất cả'
            }
        ]
    },
    blog: {
        path: '/Blog',
        label: 'Blog-Chia sẻ'
    },
    contact: {
        path: '/Contact',
        label: 'Contact'
    }
});

// EXTERNAL MODULE: ./components/header/header.module.css
var header_module = __webpack_require__(4814);
var header_module_default = /*#__PURE__*/__webpack_require__.n(header_module);
// EXTERNAL MODULE: ./components/auth/Auth.js + 3 modules
var Auth = __webpack_require__(7374);
// EXTERNAL MODULE: ./utils/isMobile.js
var utils_isMobile = __webpack_require__(9274);
;// CONCATENATED MODULE: ./components/header/Header.js

/* eslint-disable @next/next/no-img-element */ /* eslint-disable jsx-a11y/role-supports-aria-props */ 








const Header = ()=>{
    const [showMenu, setShowMenu] = external_react_default().useState(false);
    const isMobile = (0,utils_isMobile/* default */.Z)("991");
    function ShowHide() {
        setShowMenu(!showMenu);
    }
    return(/*#__PURE__*/ jsx_runtime_.jsx("header", {
        className: "navbar-light navbar-sticky header-static border-bottom border-warning nav-bg-dl",
        children: /*#__PURE__*/ jsx_runtime_.jsx("nav", {
            className: `navbar navbar-expand-lg navbar-light nav-bg-dl p-0 ${(header_module_default()).navbar}`,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container-fluid",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "pt-1 pb-1",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                            className: "navbar-brand",
                            href: "/",
                            passHref: true,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    width: 35,
                                    src: "/media/img/logo.png",
                                    alt: "logo"
                                })
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: `collapse navbar-collapse ${(header_module_default()).navbar__menu}`,
                        id: "navbarSupportedContent",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                            className: "navbar-nav mb-lg-0",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: "nav-item",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                        href: header_data.home.path,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            className: "nav-link active text-main-b-dl fw500",
                                            "aria-current": "page",
                                            children: header_data.home.label
                                        })
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    className: "nav-item dropdown",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: header_data.study.main.path,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: "nav-link dropdown-toggle text-main-b-dl fw500",
                                                id: "navbarDropdown",
                                                role: "button",
                                                "data-bs-toggle": "dropdown",
                                                "aria-expanded": "false",
                                                children: header_data.study.main.label
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                            className: "dropdown-menu mt-1 p-0",
                                            "aria-labelledby": "navbarDropdown",
                                            children: header_data.study.sub.map((item, index)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                        href: item.path,
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                            className: "dropdown-item",
                                                            children: item.label
                                                        })
                                                    })
                                                }, index)
                                            )
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    className: "nav-item dropdown",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: header_data.epsinfo.main.path,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: "nav-link dropdown-toggle text-main-b-dl fw500",
                                                id: "navbarDropdown",
                                                role: "button",
                                                "data-bs-toggle": "dropdown",
                                                "aria-expanded": "false",
                                                children: header_data.epsinfo.main.label
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                            className: "dropdown-menu mt-1 p-0",
                                            "aria-labelledby": "navbarDropdown",
                                            children: header_data.epsinfo.sub.map((item, index)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                        href: item.path,
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                            className: "dropdown-item",
                                                            children: item.label
                                                        })
                                                    })
                                                }, index)
                                            )
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: "nav-item",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                        href: header_data.blog.path,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            className: "nav-link text-main-b-dl fw500",
                                            children: header_data.blog.label
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: "nav-item",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                        href: header_data.contact.path,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            className: "nav-link text-main-b-dl fw500",
                                            children: header_data.contact.label
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    style: {
                                        paddingBottom: "13px"
                                    },
                                    className: `${!isMobile && "ms-4"}`,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(ThemeSwitcher, {})
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        style: {
                            height: "45px"
                        },
                        className: `d-flex pe-2 p-0 pb-1 align-middle ${(header_module_default()).navbar__user}`,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                suppressHydrationWarning: true,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(Auth/* default */.Z, {})
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "navbar-toggler btn border-0 p-1 pe-2 m-0",
                                "data-bs-toggle": "collapse",
                                "data-bs-target": "#navbarSupportedContent",
                                "aria-controls": "navbarSupportedContent",
                                "aria-expanded": "false",
                                "aria-label": "Toggle navigation",
                                children: !showMenu ? /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "text-main-b-dl",
                                    onClick: ShowHide,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((MenuTwoTone_default()), {
                                        style: {
                                            fontSize: "35px"
                                        }
                                    })
                                }) : /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "text-main-b-dl",
                                    onClick: ShowHide,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Close_default()), {
                                        style: {
                                            fontSize: "35px",
                                            color: "#ff8c00"
                                        }
                                    })
                                })
                            })
                        ]
                    })
                ]
            })
        })
    }));
};
/* harmony default export */ const header_Header = (Header);

// EXTERNAL MODULE: ./components/footer/footer.js
var footer = __webpack_require__(1035);
;// CONCATENATED MODULE: ./components/DefaultLayout.js




function DefaultLayout({ children  }) {
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)((external_react_default()).Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(header_Header, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("main", {
                id: "content",
                className: "bg-dl",
                children: children
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(footer/* default */.Z, {})
        ]
    }));
};


/***/ })

};
;