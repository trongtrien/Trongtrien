"use strict";
exports.id = 9692;
exports.ids = [9692];
exports.modules = {

/***/ 9692:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Practice)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Scoresheet__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9575);
/* harmony import */ var _apiRequest_Axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8420);
/* harmony import */ var _utils_isMobile__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9274);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(271);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6153);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(universal_cookie__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_7__);

/* eslint-disable @next/next/no-img-element */ 






function Practice({ questions  }) {
    var ref4, ref1, ref2, ref3;
    const { 0: currentQuestion , 1: setCurrentQuestion  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const { 0: selectedOptions , 1: setSelectedOptions  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const { 0: score , 1: setScore  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const { 0: showScore , 1: setShowScore  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    // localstorage
    const handleAnswerOption = (answer)=>{
        setSelectedOptions([
            selectedOptions[currentQuestion] = {
                answerByUser: answer
            }, 
        ]);
        setSelectedOptions([
            ...selectedOptions
        ]);
    };
    const handlePrevious = ()=>{
        const prevQues = currentQuestion - 1;
        prevQues >= 0 && setCurrentQuestion(prevQues);
    };
    const handleNext = ()=>{
        const nextQues = currentQuestion + 1;
        nextQues < questions.length && setCurrentQuestion(nextQues);
    };
    const handleSubmitButton = ()=>{
        let newScore = 0;
        console.log(selectedOptions);
        for(let i = 0; i < questions.length; i++){
            var ref;
            questions[i].answer === ((ref = selectedOptions[i]) === null || ref === void 0 ? void 0 : ref.answerByUser) && (newScore += 1);
        }
        setScore(newScore);
        setShowScore(true);
        localStorage.setItem('block', "true");
        console.log(localStorage.getItem('block'));
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "container",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "col",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "border border-warning rounded",
                    children: showScore ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                        className: "text-3xl font-semibold text-center",
                        children: [
                            "You scored ",
                            score,
                            " out of ",
                            questions.length
                        ]
                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "border border-warning rounded",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h3", {
                                className: "mb-2 mt-2 text-center",
                                children: [
                                    "Question ",
                                    currentQuestion + 1,
                                    " of ",
                                    questions.length
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "row m-0",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "p-0",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        style: {
                                            width: "100%"
                                        },
                                        src: `/media/img/exam/${questions[currentQuestion].question}`,
                                        alt: ""
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "form-body mt-3",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "radio",
                                        onClick: (e)=>handleAnswerOption("1")
                                        ,
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    type: "radio",
                                                    name: "1",
                                                    value: "1",
                                                    checked: "1" === ((ref4 = selectedOptions[currentQuestion]) === null || ref4 === void 0 ? void 0 : ref4.answerByUser),
                                                    onChange: (e)=>handleAnswerOption("1")
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "mark",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "check-answer",
                                                            children: "1"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "ps-4",
                                                            children: questions[currentQuestion].option1
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "radio",
                                        onClick: (e)=>handleAnswerOption("2")
                                        ,
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    type: "radio",
                                                    name: "2",
                                                    value: "2",
                                                    checked: "2" === ((ref1 = selectedOptions[currentQuestion]) === null || ref1 === void 0 ? void 0 : ref1.answerByUser),
                                                    onChange: (e)=>handleAnswerOption("2")
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "mark",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "check-answer",
                                                            children: "2"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "ps-4",
                                                            children: questions[currentQuestion].option2
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "radio",
                                        onClick: (e)=>handleAnswerOption("3")
                                        ,
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    type: "radio",
                                                    name: "3",
                                                    value: "3",
                                                    checked: "3" === ((ref2 = selectedOptions[currentQuestion]) === null || ref2 === void 0 ? void 0 : ref2.answerByUser),
                                                    onChange: (e)=>handleAnswerOption("3")
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "mark",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "check-answer",
                                                            children: "3"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "ps-4",
                                                            children: questions[currentQuestion].option3
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "radio",
                                        onClick: (e)=>handleAnswerOption("4")
                                        ,
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    type: "radio",
                                                    name: "4",
                                                    value: "4",
                                                    checked: "4" === ((ref3 = selectedOptions[currentQuestion]) === null || ref3 === void 0 ? void 0 : ref3.answerByUser),
                                                    onChange: (e)=>handleAnswerOption("4")
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "mark",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "check-answer",
                                                            children: "4"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "ps-4",
                                                            children: questions[currentQuestion].option4
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "form-footer d-flex p-4 border-top border-warning",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        className: "btn btn-exam-next btn-exam",
                                        role: "button",
                                        children: "X\xe1c nhận đ\xe1p \xe1n"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        className: "btn btn-exam-next btn-exam ms-auto",
                                        role: "button",
                                        onClick: currentQuestion + 1 === questions.length ? handleSubmitButton : handleNext,
                                        children: currentQuestion + 1 === questions.length ? "Submit" : "Next"
                                    })
                                ]
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "col-md-1 column"
                })
            ]
        })
    }));
};


/***/ })

};
;