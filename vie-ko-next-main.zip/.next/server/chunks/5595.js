"use strict";
exports.id = 5595;
exports.ids = [5595];
exports.modules = {

/***/ 5595:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ CourseLayout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "@mui/icons-material/MenuTwoTone"
var MenuTwoTone_ = __webpack_require__(984);
var MenuTwoTone_default = /*#__PURE__*/__webpack_require__.n(MenuTwoTone_);
// EXTERNAL MODULE: external "@mui/icons-material/Close"
var Close_ = __webpack_require__(4173);
var Close_default = /*#__PURE__*/__webpack_require__.n(Close_);
// EXTERNAL MODULE: ./components/auth/Auth.js + 3 modules
var Auth = __webpack_require__(7374);
// EXTERNAL MODULE: ./utils/isMobile.js
var utils_isMobile = __webpack_require__(9274);
// EXTERNAL MODULE: external "@mui/material/Breadcrumbs"
var Breadcrumbs_ = __webpack_require__(7185);
var Breadcrumbs_default = /*#__PURE__*/__webpack_require__.n(Breadcrumbs_);
// EXTERNAL MODULE: external "@mui/material/Typography"
var Typography_ = __webpack_require__(5858);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography_);
// EXTERNAL MODULE: external "@mui/material/Link"
var Link_ = __webpack_require__(5246);
var Link_default = /*#__PURE__*/__webpack_require__.n(Link_);
// EXTERNAL MODULE: external "@mui/material/Stack"
var Stack_ = __webpack_require__(8742);
var Stack_default = /*#__PURE__*/__webpack_require__.n(Stack_);
;// CONCATENATED MODULE: ./components/header/Breadcrumbs.js







function CustomSeparator({ chapterLabel , lesonLabel , partLabel , link  }) {
    const chapterLink = `/Course/${link}`;
    const ismobile = (0,utils_isMobile/* default */.Z)('500');
    const breadcrumbs = [
        /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
            underline: "none",
            href: "/Course",
            children: ismobile ? 'Eps' : 'Eps-Topik'
        }, "1"),
        /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
            underline: "none",
            href: chapterLink,
            children: chapterLabel
        }, "2"),
        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
            style: {
                color: "#123"
            },
            children: [
                lesonLabel,
                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    children: partLabel
                })
            ]
        }, "3")
    ];
    return(/*#__PURE__*/ jsx_runtime_.jsx((Stack_default()), {
        spacing: 2,
        children: /*#__PURE__*/ jsx_runtime_.jsx((Breadcrumbs_default()), {
            separator: "›",
            "aria-label": "breadcrumb",
            children: breadcrumbs
        })
    }));
};

;// CONCATENATED MODULE: ./components/header/CourseHeader.js

/* eslint-disable @next/next/no-img-element */ /* eslint-disable jsx-a11y/role-supports-aria-props */ 






const CourseHeader = ({ chapterLabel , lesonLabel , link , setShowMenu , showMenu  })=>{
    const isMobile = (0,utils_isMobile/* default */.Z)('1200');
    return(/*#__PURE__*/ jsx_runtime_.jsx("header", {
        className: "border-bottom border-warning nav-bg-dl",
        children: /*#__PURE__*/ jsx_runtime_.jsx("nav", {
            style: {
                display: 'block'
            },
            className: `navbar nav-bg-dl p-0`,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "d-flex",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "pt-1 pb-1 ps-3",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                            className: "navbar-brand",
                            href: "/",
                            passHref: true,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    width: 35,
                                    src: "/media/img/logo.png",
                                    alt: "logo"
                                })
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "mt-2 ms-3 p-1",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(CustomSeparator, {
                            chapterLabel: chapterLabel,
                            lesonLabel: lesonLabel,
                            link: link
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        style: {
                            height: "45px"
                        },
                        className: `pe-2 p-0 pb-1 ms-auto`,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                isMobile && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "menu-btn",
                                    children: !showMenu ? /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: "btn border-0",
                                        onClick: ()=>setShowMenu(!showMenu)
                                        ,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((MenuTwoTone_default()), {
                                            style: {
                                                fontSize: "35px",
                                                color: "#517ca4"
                                            }
                                        })
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: "btn border-0",
                                        onClick: ()=>setShowMenu(!showMenu)
                                        ,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Close_default()), {
                                            style: {
                                                fontSize: "35px",
                                                color: "#ff8c00"
                                            }
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: `${isMobile ? "me-5" : ""}`,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Auth/* default */.Z, {})
                                })
                            ]
                        })
                    })
                ]
            })
        })
    }));
};
/* harmony default export */ const header_CourseHeader = (CourseHeader);

;// CONCATENATED MODULE: ./components/CourseLayout.js



function CourseLayout({ children , link , setShowMenu , showMenu , chapterLabel , lesonLabel  }) {
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)((external_react_default()).Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(header_CourseHeader, {
                link: link,
                setShowMenu: setShowMenu,
                showMenu: showMenu,
                chapterLabel: chapterLabel,
                lesonLabel: lesonLabel
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("main", {
                id: "content",
                className: "bg-dl",
                children: children
            })
        ]
    }));
};


/***/ })

};
;