"use strict";
exports.id = 3152;
exports.ids = [3152];
exports.modules = {

/***/ 1735:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Adsense)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


function Adsense({ slot  }) {
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ins", {
        className: "adsbygoogle",
        style: {
            display: "block"
        },
        "data-ad-client": "ca-pub-5447521007783136",
        "data-ad-slot": slot,
        "data-ad-format": "auto",
        "data-full-width-responsive": "true"
    }));
};


/***/ }),

/***/ 3152:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Exam)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "@emailjs/browser"
var browser_ = __webpack_require__(7163);
var browser_default = /*#__PURE__*/__webpack_require__.n(browser_);
;// CONCATENATED MODULE: ./components/exam/sendResult.js



const ContactUs = ({ score , name , examId , setShowScore , email  })=>{
    const [show, setShow] = external_react_default().useState(false);
    const form = (0,external_react_.useRef)();
    const sendEmail = (e)=>{
        e.preventDefault();
        // serviceID: string, templateID: string, form: string | HTMLFormElement, publicKey
        browser_default().sendForm('service_y9ia8nd', 'template_dsnh7ls', form.current, 'drEmL9JG_FYfIX-VM');
    };
    return(/*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
            className: "d-flex flex-column",
            id: "myForm",
            ref: form,
            onSubmit: sendEmail,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        hidden: true,
                        name: "name",
                        type: "text",
                        className: "form-control",
                        value: name,
                        readOnly: true
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        hidden: true,
                        name: "score",
                        type: "text",
                        className: "form-control",
                        value: score,
                        readOnly: true
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        hidden: true,
                        name: "examId",
                        type: "text",
                        className: "form-control",
                        value: examId,
                        readOnly: true
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        hidden: true,
                        name: "email",
                        type: "email",
                        className: "form-control",
                        value: email,
                        readOnly: true
                    })
                }),
                !show && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                            className: "text-center pt-3 pb-3",
                            children: "Ch\xfac mừng bạn đ\xe3 ho\xe0n th\xe0nh b\xe0i thi nhấn n\xfat b\xean dưới để"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                            className: "text-center",
                            children: "Click to show result"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                            className: "text-center",
                            children: "fdfdf"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            className: "btn btn-main-y fs-4 rounded",
                            type: "submit",
                            onClick: ()=>{
                                setTimeout(()=>{
                                    setShowScore(true);
                                    setShow(true);
                                }, 1000);
                            },
                            children: "Xem kết quả"
                        })
                    ]
                })
            ]
        })
    }));
};
/* harmony default export */ const sendResult = (ContactUs);

;// CONCATENATED MODULE: ./components/exam/Scoresheet.js



const ScoreSheet = ({ score , questions , examId , name , email  })=>{
    const [showScore, setShowScore] = external_react_default().useState(false);
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(sendResult, {
                score: score,
                examId: examId,
                name: name,
                setShowScore: setShowScore,
                email: email
            }),
            showScore && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                    className: " font-semibold text-center",
                    children: [
                        "You scored ",
                        score,
                        " out of ",
                        questions.length
                    ]
                })
            })
        ]
    }));
};
/* harmony default export */ const Scoresheet = (ScoreSheet);

// EXTERNAL MODULE: ./components/apiRequest/Axios.js
var Axios = __webpack_require__(8420);
// EXTERNAL MODULE: ./utils/isMobile.js
var isMobile = __webpack_require__(9274);
// EXTERNAL MODULE: external "sweetalert2"
var external_sweetalert2_ = __webpack_require__(271);
// EXTERNAL MODULE: external "universal-cookie"
var external_universal_cookie_ = __webpack_require__(6153);
var external_universal_cookie_default = /*#__PURE__*/__webpack_require__.n(external_universal_cookie_);
// EXTERNAL MODULE: external "jwt-decode"
var external_jwt_decode_ = __webpack_require__(5567);
var external_jwt_decode_default = /*#__PURE__*/__webpack_require__.n(external_jwt_decode_);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./components/ads/DisplayAds.js
var DisplayAds = __webpack_require__(1735);
// EXTERNAL MODULE: ./components/footer/footer.js
var footer = __webpack_require__(1035);
;// CONCATENATED MODULE: ./lib/secondsTo_h_m_s.js

function secondsToTime(secs) {
    let hours = Math.floor(secs / (60 * 60));
    let divisor_for_minutes = secs % (60 * 60);
    let minutes = Math.floor(divisor_for_minutes / 60);
    let divisor_for_seconds = divisor_for_minutes % 60;
    let seconds = Math.ceil(divisor_for_seconds);
    let obj = {
        "h": hours,
        "m": minutes,
        "s": seconds
    };
    return obj;
}
/* harmony default export */ const secondsTo_h_m_s = (secondsToTime);

;// CONCATENATED MODULE: ./components/exam/count.js



function CountDown(seconds) {
    const [second, setSecond] = React.useState(seconds);
    React.useEffect(()=>{
        let unmounded = true;
        if (second > 0 && unmounded) {
            setInterval(()=>setSecond((prev)=>prev - 1
                )
            , 1000);
        }
        clearInterval(second);
    }, []);
    return {
        second
    };
}
class Example extends (external_react_default()).Component {
    constructor(){
        super();
        this.state = {
            time: {},
            seconds: 120
        };
        this.timer = 0;
        this.startTimer = this.startTimer.bind(this);
        this.countDown = this.countDown.bind(this);
    }
    componentDidMount() {
        let timeLeftVar = this.secondsToTime(this.state.seconds);
        this.setState({
            time: timeLeftVar
        });
    }
    startTimer() {
        if (this.timer === 0 && this.state.seconds > 0) {
            this.timer = setInterval(this.countDown, 1000);
        }
    }
    countDown() {
        // Remove one second, set state so a re-render happens.
        let seconds = this.state.seconds - 1;
        this.setState({
            time: secondsTo_h_m_s(seconds),
            seconds: seconds
        });
        // Check if we're at zero.
        if (seconds === 0) {
            clearInterval(this.timer);
        }
    }
    render() {
        return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                    onClick: this.startTimer,
                    children: "Start"
                }),
                "m: ",
                this.state.time.m < 10 ? '0' : '',
                this.state.time.m,
                " s: ",
                this.state.time.s < 10 ? '0' : '',
                this.state.time.s
            ]
        }));
    }
}
/* harmony default export */ const count = (Example);

;// CONCATENATED MODULE: ./components/exam/index.js

/* eslint-disable @next/next/no-img-element */ 











function Exam({ questions , examId  }) {
    var ref5, ref1, ref2, ref3, ref4;
    const cookie = new (external_universal_cookie_default())();
    const token = cookie.get("TOKEN");
    const [decoded, setdecoded] = external_react_default().useState([]);
    external_react_default().useEffect(()=>{
        let mounded = true;
        if (token && mounded) {
            setdecoded(external_jwt_decode_default()(token));
        }
        return ()=>mounded = false
        ;
    }, []);
    console.log(decoded);
    const { 0: currentQuestion , 1: setCurrentQuestion  } = (0,external_react_.useState)(0);
    const { 0: selectedOptions , 1: setSelectedOptions  } = (0,external_react_.useState)([]);
    const { 0: score , 1: setScore  } = (0,external_react_.useState)(0);
    const { 0: showScore , 1: setShowScore  } = (0,external_react_.useState)(false);
    const [disabledOptions, setdisabledOptions] = external_react_default().useState(true);
    const [disabledNext, setdisabledNext] = external_react_default().useState(true);
    const [disabledConfirm, setdisabledConfirm] = external_react_default().useState(false);
    const [startStop, setStartStop] = external_react_default().useState(true);
    const handleAnswerOption = (answer)=>{
        setSelectedOptions([
            selectedOptions[currentQuestion] = {
                answerByUser: answer
            }, 
        ]);
        setSelectedOptions([
            ...selectedOptions
        ]);
        setdisabledConfirm(false);
    };
    const handleNext = ()=>{
        const nextQues = currentQuestion + 1;
        nextQues < questions.length && setCurrentQuestion(nextQues);
        setdisabledConfirm(true);
        setdisabledNext(true);
        setdisabledOptions(false);
    };
    const handleConfirms = ()=>{
        setdisabledNext(false);
        setdisabledConfirm(true);
        setdisabledOptions(true);
    };
    const handleSubmitButton = ()=>{
        let newScore = 0;
        for(let i = 0; i < questions.length; i++){
            var ref;
            questions[i].answer === ((ref = selectedOptions[i]) === null || ref === void 0 ? void 0 : ref.answerByUser) && (newScore += 5);
        }
        setScore(newScore);
        setShowScore(true);
    };
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "wrap-exam",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "row wrap-exam-top m-0",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-sm-8 col-8 col-md-8 col-xl-9",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "d-flex mt-1",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                        href: "/",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                style: {
                                                    width: '40px',
                                                    paddingBottom: '10px'
                                                },
                                                src: "/media/img/logo.png",
                                                alt: "logo"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "m-auto mt-1",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            className: "text-center fs-4",
                                            children: "Test of proficiency in Korean"
                                        })
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-sm-4 col-4 col-md-4 col-xl-3",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "d-flex",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-4",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h5", {
                                        className: "pt-2 fs-4",
                                        children: [
                                            "No: ",
                                            examId
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "d-flex col-8",
                                    children: [
                                        startStop ? /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            className: "btn btn-exam",
                                            style: {
                                                width: "48%"
                                            },
                                            onClick: ()=>{
                                                setStartStop(false);
                                                setdisabledOptions(false);
                                            },
                                            children: "Start"
                                        }) : /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            className: "btn btn-exam",
                                            style: {
                                                width: "48%"
                                            },
                                            children: "End Test"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(count, {})
                                    ]
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "row m-0",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-lg-9 m-0 p-0",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "bg-white",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "col",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "border rounded",
                                        children: showScore ? /*#__PURE__*/ jsx_runtime_.jsx(Scoresheet, {
                                            score: score,
                                            questions: questions,
                                            examId: examId,
                                            name: decoded.name,
                                            email: decoded.email
                                        }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "border rounded",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "row m-0",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "p-0",
                                                        children: token && decoded.role == "premium" ? /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                                                            children: currentQuestion < 20 ? /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                                style: {
                                                                    width: "100%"
                                                                },
                                                                src: `/media/img/exam/${questions[currentQuestion].question}`,
                                                                alt: ""
                                                            }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                children: [
                                                                    questions[currentQuestion].question_title != "" && /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                                        style: {
                                                                            width: "100%"
                                                                        },
                                                                        src: `/media/img/exam/1/${questions[currentQuestion].question_title}`,
                                                                        alt: ""
                                                                    }),
                                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                                        className: "fs-2 ps-4 fw-bolder",
                                                                        children: [
                                                                            currentQuestion + 1,
                                                                            "."
                                                                        ]
                                                                    }),
                                                                    questions[currentQuestion].question != "" && /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                                        style: {
                                                                            width: "100%"
                                                                        },
                                                                        src: `/media/img/exam/${questions[currentQuestion].question}`,
                                                                        alt: ""
                                                                    })
                                                                ]
                                                            })
                                                        }) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "ratio ratio-21x9 p-0 border rounded",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("iframe", {
                                                                src: `https://www.youtube.com/embed/dogcPvdvkCE?rel=0&amp;showinfo=0`,
                                                                controls: "0",
                                                                title: "YouTube video player",
                                                                frameBorder: "0",
                                                                allow: "fullscreen;accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture",
                                                                allowFullScreen: true
                                                            })
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "form-body mt-3",
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("fieldset", {
                                                        disabled: disabledOptions,
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "radio",
                                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                            type: "radio",
                                                                            name: "1",
                                                                            value: "1",
                                                                            checked: "1" === ((ref5 = selectedOptions[currentQuestion]) === null || ref5 === void 0 ? void 0 : ref5.answerByUser),
                                                                            onChange: (e)=>handleAnswerOption("1")
                                                                        }),
                                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                            className: "mark",
                                                                            children: [
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                                    className: "check-answer",
                                                                                    children: "1"
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                                    className: "ps-4",
                                                                                    children: questions[currentQuestion].option1
                                                                                })
                                                                            ]
                                                                        })
                                                                    ]
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "radio",
                                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                            type: "radio",
                                                                            name: "2",
                                                                            value: "2",
                                                                            checked: "2" === ((ref1 = selectedOptions[currentQuestion]) === null || ref1 === void 0 ? void 0 : ref1.answerByUser),
                                                                            onChange: (e)=>handleAnswerOption("2")
                                                                        }),
                                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                            className: "mark",
                                                                            children: [
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                                    className: "check-answer",
                                                                                    children: "2"
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                                    className: "ps-4",
                                                                                    children: questions[currentQuestion].option2
                                                                                })
                                                                            ]
                                                                        })
                                                                    ]
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "radio",
                                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                            type: "radio",
                                                                            name: "3",
                                                                            value: "3",
                                                                            checked: "3" === ((ref2 = selectedOptions[currentQuestion]) === null || ref2 === void 0 ? void 0 : ref2.answerByUser),
                                                                            onChange: (e)=>handleAnswerOption("3")
                                                                        }),
                                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                            className: "mark",
                                                                            children: [
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                                    className: "check-answer",
                                                                                    children: "3"
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                                    className: "ps-4",
                                                                                    children: questions[currentQuestion].option3
                                                                                })
                                                                            ]
                                                                        })
                                                                    ]
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "radio",
                                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                            type: "radio",
                                                                            name: "4",
                                                                            value: "4",
                                                                            checked: "4" === ((ref3 = selectedOptions[currentQuestion]) === null || ref3 === void 0 ? void 0 : ref3.answerByUser),
                                                                            onChange: (e)=>handleAnswerOption("4")
                                                                        }),
                                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                            className: "mark",
                                                                            children: [
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                                    className: "check-answer",
                                                                                    children: "4"
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                                    className: "ps-4",
                                                                                    children: questions[currentQuestion].option4
                                                                                })
                                                                            ]
                                                                        })
                                                                    ]
                                                                })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "form-footer d-flex p-4 border-top",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                            className: "btn btn-exam-next btn-exam",
                                                            disabled: disabledConfirm || startStop,
                                                            onClick: handleConfirms,
                                                            role: "button",
                                                            children: "Confirm answer"
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h3", {
                                                            className: "ms-auto mt-2",
                                                            children: [
                                                                "Your Answer: ",
                                                                (ref4 = selectedOptions[currentQuestion]) === null || ref4 === void 0 ? void 0 : ref4.answerByUser
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                            className: "btn ms-auto btn-exam-next btn-exam",
                                                            role: "button",
                                                            disabled: disabledNext || startStop,
                                                            onClick: currentQuestion + 1 === questions.length ? handleSubmitButton : handleNext,
                                                            children: currentQuestion + 1 === questions.length ? "Submit" : "Next question"
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(DisplayAds/* default */.Z, {
                                            slot: "8882564828"
                                        })
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-lg-3 wrap-exam-body-right p-1 pb-3",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "row m-0 ps-1 pe-1",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("table", {
                                className: "table border-1 table-bordered border-info mt-1 bg-light",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("thead", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("tr", {
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("td", {
                                                colSpan: 4,
                                                className: "p-0 area_time border-info",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                        src: "/media/img/area_time.jpg",
                                                        alt: ""
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                        className: "mt-2",
                                                        children: "00:50"
                                                    })
                                                ]
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tbody", {
                                        className: "border-1",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                                className: "text-center border-info",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                        colSpan: 2,
                                                        className: "pt-3 fs-5 text-info",
                                                        children: "Đọc hiểu"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                        colSpan: 2,
                                                        className: "pt-3 fs-5 text-info",
                                                        children: "Nghe hiểu"
                                                    })
                                                ]
                                            }),
                                            Array.from(Array(20).keys()).map((item)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                                    className: "text-center border-info",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                            children: item + 1
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                            className: "border-info",
                                                            children: item < selectedOptions.length && '🍥'
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                            children: 21 + item
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                            className: "border-info",
                                                            children: 4 + item < selectedOptions.length && '🍥'
                                                        })
                                                    ]
                                                }, item)
                                            )
                                        ]
                                    })
                                ]
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ jsx_runtime_.jsx(footer/* default */.Z, {})
            })
        ]
    }));
};


/***/ })

};
;