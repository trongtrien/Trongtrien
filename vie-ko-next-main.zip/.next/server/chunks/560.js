"use strict";
exports.id = 560;
exports.ids = [560];
exports.modules = {

/***/ 560:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_Card__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1712);
/* harmony import */ var _apiRequest_Axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8420);
/* harmony import */ var jwt_decode__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5567);
/* harmony import */ var jwt_decode__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(jwt_decode__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var sweetalert__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4701);
/* harmony import */ var sweetalert__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(sweetalert__WEBPACK_IMPORTED_MODULE_6__);

/* eslint-disable @next/next/no-img-element */ 





const CourseDetail = ({ data: data1 , token , // listChapterDetail
listChapterDetail  })=>{
    const chapter = listChapterDetail.chapter;
    const pageviewCount = (courseId)=>{
        (0,_apiRequest_Axios__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)({
            method: 'PUT',
            url: `/courseviews/${courseId}`
        });
    };
    const registerLesson = (courseId)=>{
        if (token) (0,_apiRequest_Axios__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)({
            method: 'POST',
            url: '/progress',
            data: {
                userId: jwt_decode__WEBPACK_IMPORTED_MODULE_4___default()(token).userId,
                course_id: courseId
            }
        });
    };
    // get new data
    const [newData, setnewData] = react__WEBPACK_IMPORTED_MODULE_1___default().useState([]);
    react__WEBPACK_IMPORTED_MODULE_1___default().useEffect(()=>{
        if (data1) setnewData(data1.filter((newdata)=>newdata.id != listChapterDetail.id
        ).sort((a, b)=>a.id - b.id
        ));
    }, [
        data1,
        chapter
    ]) // eslint-disable-line react-hooks/exhaustive-deps
    ;
    //get checkRegister
    const [checkRegister, setcheckRegister] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    react__WEBPACK_IMPORTED_MODULE_1___default().useEffect(()=>{
        let componentDidMount = true;
        if (componentDidMount && token && listChapterDetail.id) (0,_apiRequest_Axios__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)({
            method: 'GET',
            url: `/progress/${jwt_decode__WEBPACK_IMPORTED_MODULE_4___default()(token).userId}`
        }).then((res)=>setcheckRegister(res.data.find((data)=>data.course_id == listChapterDetail.id
            ))
        );
        return ()=>componentDidMount = false
        ;
    }, [
        listChapterDetail.id,
        token
    ]);
    const [show, setshow] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    function Show() {
        setshow(!show);
    }
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "container pb-4",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "pt-5",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: "pt-3 mb-4",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                            className: "btn-main-y rounded-3 ps-4 pe-4 p-2",
                            children: [
                                "Kh\xf3a học (",
                                listChapterDetail.lessonLabel,
                                ")"
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "text-dl mb-4 mt-0 fs-4",
                        children: [
                            chapter === "Chapter1" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    children: [
                                        " ( Nằm trong gi\xe1o tr\xecnh 한국어 표준교재 1 từ b\xe0i 1 đến b\xe0i 30)",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        "Kh\xf3a học tập trung kiến thức cho những ai muốn học để thi EPS-TOPIK"
                                    ]
                                })
                            }),
                            chapter === "Chapter2" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    children: [
                                        "( Nằm trong gi\xe1o tr\xecnh 한국어 표준교재 2 từ b\xe0i 31 đến b\xe0i 60)",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        "Kh\xf3a học tập trung kiến thức cho những ai muốn học để thi EPS-TOPIK"
                                    ]
                                })
                            }),
                            (chapter === "Practice-listen" || chapter === "Practice-read") && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    children: [
                                        "( Đ\xe2y l\xe0 kh\xf3a luyện l\xe0m bộ 2000 c\xe2u)",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        "Kết hợp xem video giải đề v\xe0 thực h\xe0nh l\xe0m b\xe0i trắc nghiệm để củng cố lại kiến thức v\xe0 l\xe0m quen c\xe1ch thức thi"
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                type: "button",
                                className: "btn-main-y rounded-3 ps-4 pe-4 p-2 fs-5",
                                onClick: ()=>{
                                    pageviewCount(listChapterDetail.id);
                                    setTimeout(()=>next_router__WEBPACK_IMPORTED_MODULE_5___default().push(listChapterDetail.goLink)
                                    , 200);
                                },
                                children: "V\xe0o học"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                type: "button",
                                className: "btn-main-y rounded-3 ps-4 pe-4 p-2 fs-5 ms-2",
                                onClick: ()=>{
                                    if (!checkRegister && token) {
                                        registerLesson(listChapterDetail.id);
                                        setTimeout(()=>{
                                            sweetalert__WEBPACK_IMPORTED_MODULE_6___default()({
                                                text: "Bạn đ\xe3 ghi danh th\xe0nh c\xf4ng, chăm chỉ học nh\xe9!"
                                            }).then(()=>next_router__WEBPACK_IMPORTED_MODULE_5___default().reload()
                                            );
                                        });
                                    } else if (!token) {
                                        sweetalert__WEBPACK_IMPORTED_MODULE_6___default()({
                                            text: "Bạn chưa (đăng nhập/đăng k\xfd) th\xe0nh vi\xean. Vui l\xf2ng (đăng nhập/đăng k\xfd) để ghi danh ạ"
                                        });
                                    } else {
                                        sweetalert__WEBPACK_IMPORTED_MODULE_6___default()({
                                            text: "Bạn đ\xe3 ghi danh kh\xf3a học rồi ạ, nếu chưa v\xe0o học được h\xe3y li\xean hệ để m\xecnh kiểm tra ạ"
                                        });
                                    }
                                },
                                children: "Ghi danh"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mt-3",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                type: "button",
                                className: "btn-main-y rounded-3 ps-4 pe-4 p-2 fs-5",
                                onClick: Show,
                                children: show ? 'Tắt hướng dẫn sử dụng kh\xf3a học' : 'Hướng dẫn sử dụng kh\xf3a học'
                            }),
                            show && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "ratio ratio-16x9 mt-3",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("iframe", {
                                    width: "100%",
                                    height: "100%",
                                    src: "https://www.youtube.com/embed/7ICd0_CmnUg?rel=0&modestbranding=1&autohide=1&showinfo=0&enablejsapi=1",
                                    title: "YouTube video player",
                                    frameBorder: "0",
                                    allow: "fullscreen; accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture",
                                    allowFullScreen: true
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "mt-5",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                    className: "text-dl",
                    children: [
                        "\xa0",
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            height: 40,
                            src: "/media/img/mui_ten_r.png",
                            alt: ""
                        }),
                        "\xa0\xa0C\xe1c kh\xf3a học kh\xe1c"
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "row pb-3",
                children: newData && newData.map((item, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-sm-12 col-md-6 col-lg-6 col-xl-3 mt-5",
                        children: item.id < 10 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_utils_Card__WEBPACK_IMPORTED_MODULE_2__/* .EpsCard */ .x, {
                            data: item
                        })
                    }, index)
                )
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CourseDetail);


/***/ })

};
;