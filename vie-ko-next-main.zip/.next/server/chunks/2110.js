"use strict";
exports.id = 2110;
exports.ids = [2110];
exports.modules = {

/***/ 5243:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const ProgressBar = ({ bgcolor , progress , height  })=>{
    const Parentdiv = {
        height: height,
        padding: 1,
        width: '100%',
        backgroundColor: 'rgba(255, 140, 0, 0.25)',
        borderRadius: 10
    };
    const Childdiv = {
        height: '100%',
        width: `${progress}%`,
        backgroundColor: bgcolor,
        borderRadius: 10,
        textAlign: 'right'
    };
    const progresstext = {
        color: 'white',
        fontWeight: 400,
        fontSize: 12,
        paddingTop: 1,
        lineHeight: 1
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        style: Parentdiv,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            style: Childdiv,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: "pe-2",
                style: progresstext,
                children: `${progress}%`
            })
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProgressBar);


/***/ }),

/***/ 2117:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ notes_Note)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "sweetalert"
var external_sweetalert_ = __webpack_require__(4701);
var external_sweetalert_default = /*#__PURE__*/__webpack_require__.n(external_sweetalert_);
// EXTERNAL MODULE: ./components/apiRequest/Axios.js
var Axios = __webpack_require__(8420);
;// CONCATENATED MODULE: ./components/notes/api.js
const updateNoteWhenCreated = async ({ title , message , startAt  })=>{
    return {
        title: title,
        message: message,
        startAt: startAt
    };
};
const updateNoteWhenDeleted = async ()=>{
    return {};
};

;// CONCATENATED MODULE: ./components/notes/Note.js





const Note = ({ urlApi , userId , lessonId , currentTime , setStartAt , setplaying  })=>{
    const { 0: data1 , 1: setData  } = (0,external_react_.useState)([]);
    const { 0: message , 1: setmessage  } = (0,external_react_.useState)([]);
    const { 0: title , 1: setTitle  } = (0,external_react_.useState)([]);
    const { 0: noteState , 1: setNoteState  } = (0,external_react_.useState)(false);
    (0,external_react_.useEffect)(()=>{
        (0,Axios/* default */.Z)({
            method: "GET",
            url: `/${urlApi}/${lessonId}`
        }).then((res)=>res.data.filter((data)=>Number(data.userId) === userId
            )
        ).then((res)=>setData(res.sort((a, b)=>a.id - b.id
            ))
        );
    }, [
        lessonId,
        userId,
        urlApi
    ]);
    const createNote = (e)=>{
        e.preventDefault();
        updateNoteWhenCreated({
            title: title,
            message: message,
            startAt: currentTime
        }).then((note)=>{
            setData([
                note,
                ...data1
            ]);
        });
        // startAt nho cap nhat
        (0,Axios/* default */.Z)({
            method: "POST",
            url: `/${urlApi}`,
            data: {
                lesson_id: lessonId,
                userId: userId,
                title: title.replace(/[^\p{L}\s0-9]/gu, ''),
                message: message.replace(/[^\p{L}\s0-9]/gu, ''),
                startAt: currentTime
            }
        });
        setNoteState(false);
        setmessage("");
        setTitle("");
        setplaying(true);
    };
    const deleteNote = (noteId)=>{
        external_sweetalert_default()({
            title: "Bạn muốn x\xf3a ghi ch\xfa?",
            buttons: true,
            dangerMode: true,
            icon: "warning"
        }).then((willDelete)=>{
            if (willDelete) {
                external_sweetalert_default()({
                    text: "Ghi ch\xfa đ\xe3 bị x\xf3a",
                    icon: "success"
                });
                updateNoteWhenDeleted().then(()=>{
                    (0,Axios/* default */.Z)({
                        method: "DELETE",
                        url: `/${urlApi}/${noteId}`
                    });
                    const updatednotes = data1.filter((notes)=>notes.id !== noteId
                    );
                    setData(updatednotes);
                });
            }
        });
    };
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "pb-3",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "mb-4",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                        className: "mb-3 rounded border-info",
                        style: {
                            background: "transparent"
                        },
                        onClick: ()=>{
                            setNoteState(!noteState);
                            setplaying(false);
                        },
                        children: [
                            "Th\xeam ghi ch\xfa ",
                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                className: "fa fa-plus ms-2 text-logo-b",
                                "aria-hidden": "true"
                            })
                        ]
                    }),
                    noteState && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                        onSubmit: createNote,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                htmlFor: "Title",
                                className: "mt-3",
                                children: "Ti\xeau đề:"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                name: "Title",
                                id: "Title",
                                type: "text",
                                className: "form-control",
                                value: title,
                                onChange: (e)=>setTitle(e.target.value)
                                ,
                                required: true
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                htmlFor: "message",
                                className: "mt-3",
                                children: "Nội dung:"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                                id: "message",
                                className: "form-control",
                                name: "message",
                                value: message,
                                onChange: (e)=>setmessage(e.target.value)
                                ,
                                rows: 5
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "btn btn-main-y mt-2",
                                type: "submit",
                                children: "Submit"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "border border-warning rounded",
                children: data1.length ? data1.map((newdata)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "border-bottom pb-3 pt-2",
                        style: {
                            borderBottom: "1px dashed rgb(86, 86, 86)"
                        },
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "ps-3 m-0",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                        className: "text-logo-b",
                                        children: newdata.title
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: newdata.message
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "d-flex",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                        className: "btn btn-main-y ms-3",
                                        onClick: ()=>{
                                            setStartAt(newdata.startAt);
                                            setplaying(true);
                                        },
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "fa fa-hand-o-right",
                                                "aria-hidden": "true"
                                            }),
                                            " Video Play"
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: "btn btn-danger ms-2",
                                        onClick: ()=>deleteNote(newdata.id)
                                        ,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "fa fa-trash-o",
                                            "aria-hidden": "true"
                                        })
                                    })
                                ]
                            })
                        ]
                    }, newdata.id)
                ) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "p-0 m-0",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                        className: "text-logo-b pt-1 ps-3",
                        children: "Chưa c\xf3 ghi ch\xfa n\xe0o"
                    })
                })
            })
        ]
    }));
};
/* harmony default export */ const notes_Note = (Note);


/***/ }),

/***/ 1394:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "x": () => (/* binding */ TimeCalculator)
/* harmony export */ });
function TimeCalculator(seconds) {
    const hh = Math.floor(seconds / 60 / 60).toString();
    const mm = pad(Math.floor((seconds - hh * 3600) / 60));
    const ss = pad(seconds - mm * 60);
    function pad(string) {
        return ('0' + string).slice(-2);
    }
    return {
        hh: seconds > 0 ? hh : '00',
        mm: seconds > 0 ? mm : '00',
        ss: seconds > 0 ? ss : '00'
    };
}


/***/ }),

/***/ 3898:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_player_youtube__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1701);
/* harmony import */ var react_player_youtube__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_player_youtube__WEBPACK_IMPORTED_MODULE_2__);



function Player({ videoId , startAt , playing , setPlayingSeconds , setplaying , setDuration , setPlayedSeconds ,  }) {
    const { 0: played , 1: setplayed  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_player_youtube__WEBPACK_IMPORTED_MODULE_2___default()), {
        width: "100%",
        height: "100%",
        url: `https://www.youtube.com/watch?v=${videoId}?start=${startAt}`,
        controls: true,
        playing: playing,
        onPlay: ()=>setplaying(true)
        ,
        onPause: ()=>{
            setPlayedSeconds(played);
            setplaying(false);
        },
        onProgress: ({ playedSeconds  })=>{
            setplayed(playedSeconds.toFixed());
            setPlayingSeconds(playedSeconds.toFixed());
        },
        onDuration: (duration)=>setDuration(duration.toFixed())
    }));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Player);


/***/ })

};
;