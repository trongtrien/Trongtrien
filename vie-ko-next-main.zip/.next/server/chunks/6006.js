"use strict";
exports.id = 6006;
exports.ids = [6006];
exports.modules = {

/***/ 6006:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _baseUrl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7105);
/* harmony import */ var react_facebook__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3266);
/* harmony import */ var react_facebook__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_facebook__WEBPACK_IMPORTED_MODULE_2__);




const Fbcomment = ({ url  })=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "bg-light rounded border border-warning pt-2",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_facebook__WEBPACK_IMPORTED_MODULE_2__.FacebookProvider, {
            appId: "155570839747933",
            className: "row",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_facebook__WEBPACK_IMPORTED_MODULE_2__.Like, {
                    href: `${_baseUrl__WEBPACK_IMPORTED_MODULE_3__/* .baseUrl */ .F}${url}`,
                    colorScheme: "dark",
                    showFaces: true,
                    share: true
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "p-2 text-dark",
                    children: "Mời bạn để lại b\xecnh luận hoặc g\xf3p \xfd để bọn m\xecnh ho\xe0n thiện nội dung tốt hơn nha"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_facebook__WEBPACK_IMPORTED_MODULE_2__.Comments, {
                    href: `${_baseUrl__WEBPACK_IMPORTED_MODULE_3__/* .baseUrl */ .F}${url}`
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Fbcomment);


/***/ })

};
;