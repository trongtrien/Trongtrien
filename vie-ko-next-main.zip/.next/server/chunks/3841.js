"use strict";
exports.id = 3841;
exports.ids = [3841];
exports.modules = {

/***/ 3841:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ utils_PostTemplate)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/ads/DisplayAds.js
var DisplayAds = __webpack_require__(1735);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
var router_default = /*#__PURE__*/__webpack_require__.n(router_);
;// CONCATENATED MODULE: ./utils/Pagination.js




const Pagination = ({ disabled , page , parentPage  })=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx("nav", {
        className: "bg-dl p-0 m-0",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
            className: "pagination bg-dl",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    className: `page-item bg-dl ${(disabled >= 6 || page <= 1) && 'disabled'}`,
                    children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        className: "page-link bg-dl text-dl",
                        onClick: ()=>router_default().push(`${parentPage}/?page=${page - 1}`)
                        ,
                        disabled: disabled >= 6 || page <= 1,
                        children: "PREV"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    className: `page-item ${page === 1 && 'active'}`,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                        href: `${parentPage}/?page=1`,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            className: "page-link bg-dl text-dl",
                            children: "1"
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    className: `page-item ${disabled < 6 && 'disabled'} ${page === 2 && 'active'}`,
                    "aria-current": "page",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                        href: `${parentPage}/?page=2`,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            className: "page-link bg-dl text-dl",
                            children: "2"
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    className: `page-item ${disabled < 6 && 'disabled'}`,
                    children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        className: "page-link bg-dl text-dl",
                        onClick: ()=>router_default().push(`${parentPage}/?page=${page + 1}`)
                        ,
                        disabled: disabled < 6,
                        children: "Next"
                    })
                })
            ]
        })
    }));
};
/* harmony default export */ const utils_Pagination = (Pagination);

// EXTERNAL MODULE: ./utils/RecentPost.js
var RecentPost = __webpack_require__(62);
// EXTERNAL MODULE: ./utils/Tag.js
var Tag = __webpack_require__(8694);
// EXTERNAL MODULE: ./utils/isMobile.js
var utils_isMobile = __webpack_require__(9274);
;// CONCATENATED MODULE: ./utils/PostTemplate.js

/* eslint-disable @next/next/no-img-element */ 






const PostTemplate = ({ post: post1 , recentpost , title , parentPage , disabled , page , imgURL  })=>{
    const isMobile = (0,utils_isMobile/* default */.Z)('911');
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "container p-0 pt-3",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                className: "m-0 text-dl ps-3 text-logo-b",
                children: title
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "row text-dl ps-3 pe-3 m-0",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "col-lg-8 ps-0 pe-0 ",
                        children: [
                            !isMobile ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "row pb-5 pt-3",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    src: `/media/img/${imgURL}/banner.jpg`,
                                    alt: ""
                                })
                            }) : /*#__PURE__*/ jsx_runtime_.jsx("hr", {}),
                            post1.map((post, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "row border-bottom border-warning-50 pb-5 pt-3",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "col-md-4 col-xl-3 pb-3 pt-1",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                className: "rounded",
                                                style: {
                                                    width: "100%"
                                                },
                                                src: `/media/img/${imgURL}/s${post.imgURL}`,
                                                alt: ""
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "col-md-8 col-xl-9",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                    className: "p-0",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                        href: `${parentPage}/${post.page}`,
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                            className: "text-main-b-dl",
                                                            children: post.title
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "d-flex pt-1 pb-2",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "me-2 text-secondary",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                className: "fa fa-calendar",
                                                                "aria-hidden": "true"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "me-2 text-secondary",
                                                            children: post.createAt
                                                        }),
                                                        "|",
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "me-2 ms-2 text-secondary",
                                                            children: "Viết bởi - Admin"
                                                        }),
                                                        "|",
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                            className: "me-2 ms-2 text-secondary",
                                                            children: [
                                                                post.pageview,
                                                                " ",
                                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                    className: "fa fa-eye text-logo-b",
                                                                    "aria-hidden": "true"
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    dangerouslySetInnerHTML: {
                                                        __html: post.description
                                                    }
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    className: "rounded-pill btn-main-y p-1 ps-3 pe-3 btn",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                        href: `${parentPage}/${post.page}`,
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                            className: "text-light",
                                                            children: "Xem chi tiết ..."
                                                        })
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                }, index)
                            ),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "m-0 p-0 pt-5",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(utils_Pagination, {
                                    page: page,
                                    disabled: disabled,
                                    parentPage: parentPage
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "m-0 p-0 pt-2 pb-2",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(DisplayAds/* default */.Z, {
                                    slot: "8882564828"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "col-lg-4 ps-4 mt-3",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(Tag/* default */.Z, {}),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "rounded border border-warning mt-3 mb-3 ps-3 pe-3 pb-3",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                        className: "title pt-3 pb-2 text-main-b-dl",
                                        children: "B\xe0i viết mới nhất"
                                    }),
                                    recentpost && recentpost.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "border-warning pb-2 mb-2",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(RecentPost/* default */.Z, {
                                                link: `${parentPage}/${item.page}`,
                                                date: item.createAt,
                                                title: item.title,
                                                view: item.pageview
                                            })
                                        }, item.id)
                                    ),
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: "rounded-pill btn-main-y p-1 ps-3 pe-3 btn",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: parentPage,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: "text-light",
                                                children: "Xem tất cả"
                                            })
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "rounded border border-warning mt-3 mb-3",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(DisplayAds/* default */.Z, {
                                    slot: "8882564828"
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const utils_PostTemplate = (PostTemplate);


/***/ })

};
;