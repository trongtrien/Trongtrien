"use strict";
exports.id = 2088;
exports.ids = [2088];
exports.modules = {

/***/ 2088:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ShareSocial)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _baseUrl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7105);
/* harmony import */ var react_share__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6158);
/* harmony import */ var react_share__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_share__WEBPACK_IMPORTED_MODULE_2__);




function ShareSocial({ shareUrl , title  }) {
    const FacebookShare = ()=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "share-social",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_2__.FacebookShareButton, {
                url: `${_baseUrl__WEBPACK_IMPORTED_MODULE_3__/* .baseUrl */ .F}${shareUrl}`,
                quote: title,
                className: "share-social__share-button",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_2__.FacebookIcon, {
                    size: 30,
                    round: true
                })
            })
        })
    ;
    const FacebookMessengerShare = ()=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "share-social",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_2__.FacebookMessengerShareButton, {
                url: `${_baseUrl__WEBPACK_IMPORTED_MODULE_3__/* .baseUrl */ .F}${shareUrl}`,
                appId: "521270401588372",
                className: "share-social__share-button",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_2__.FacebookMessengerIcon, {
                    size: 30,
                    round: true
                })
            })
        })
    ;
    const TwitterShare = ()=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "share-social",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_2__.TwitterShareButton, {
                url: `${_baseUrl__WEBPACK_IMPORTED_MODULE_3__/* .baseUrl */ .F}${shareUrl}`,
                title: title,
                className: "share-social__share-button",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_2__.TwitterIcon, {
                    size: 30,
                    round: true
                })
            })
        })
    ;
    const WhatsappShare = ()=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "share-social",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_2__.WhatsappShareButton, {
                url: `${_baseUrl__WEBPACK_IMPORTED_MODULE_3__/* .baseUrl */ .F}${shareUrl}`,
                title: title,
                separator: ":: ",
                className: "share-social__share-button",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_2__.WhatsappIcon, {
                    size: 30,
                    round: true
                })
            })
        })
    ;
    const LinkedinShare = ()=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "share-social",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_2__.LinkedinShareButton, {
                url: `${_baseUrl__WEBPACK_IMPORTED_MODULE_3__/* .baseUrl */ .F}${shareUrl}`,
                className: "share-social__share-button",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_2__.LinkedinIcon, {
                    size: 30,
                    round: true
                })
            })
        })
    ;
    const EmailShare = ()=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "share-social",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_2__.EmailShareButton, {
                url: `${_baseUrl__WEBPACK_IMPORTED_MODULE_3__/* .baseUrl */ .F}${shareUrl}`,
                subject: title,
                body: "body",
                className: "share-social__share-button",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_2__.EmailIcon, {
                    size: 30,
                    round: true
                })
            })
        })
    ;
    const ViberShare = ()=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "share-social",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_2__.ViberShareButton, {
                url: `${_baseUrl__WEBPACK_IMPORTED_MODULE_3__/* .baseUrl */ .F}${shareUrl}`,
                title: title,
                className: "share-social__share-button",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_2__.ViberIcon, {
                    size: 30,
                    round: true
                })
            })
        })
    ;
    const LineShare = ()=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "share-social",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_2__.LineShareButton, {
                url: `${_baseUrl__WEBPACK_IMPORTED_MODULE_3__/* .baseUrl */ .F}${shareUrl}`,
                title: title,
                className: "share-social__share-button",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_2__.LineIcon, {
                    size: 30,
                    round: true
                })
            })
        })
    ;
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FacebookShare, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FacebookMessengerShare, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TwitterShare, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(EmailShare, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(LineShare, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(WhatsappShare, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(LinkedinShare, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ViberShare, {})
        ]
    }));
};


/***/ })

};
;