console.log("%cHello! Bà con 👨🏻‍🎓 🤞🤞🤞","color: #ff8c00;font-size: 20px;font-weight: 500;")
console.log("%cLập trình còn gà nên mong các bạn ghé trang vì mục đích học tập thôi nhé, đừng phân tích kỹ thuật sâu tội mình nha hi hi. Mong cao thủ nương tay 🙏🏼 🙏🏼 🙏🏼 Tại hạ xin cảm tạ","color: #ff8c00;font-size: 14px;")
