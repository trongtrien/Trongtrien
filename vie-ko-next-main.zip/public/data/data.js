window.listExamsVideo = [
    [1,2],
    '',
    '',
    '',
    '',
    '0MelEOd5RDg'
]

window.listdownload = [
    {
        down:[
            {   
                title:'Bản Tiếng Việt',
                links:[
                    {
                        imgSrc:'/media/img/part1_title_vie.png',
                        link: 'https://drive.google.com/file/d/1-mnNpHrvTvT04qWQblNFirWGantBkA42/view?usp=sharing',
                        title: 'Giáo trình 60 bài phần 1',
                        adsslot: '1527911262'
                    },
                    {
                        imgSrc:'/media/img/part2_title_vie.png',
                        link: 'https://drive.google.com/file/d/15vem4HjlfbIszpJtyeD5TfkSRcfwV7nY/view?usp=sharing',
                        title: 'Giáo trình 60 bài phần 2',
                        adsslot: '5566654271'
                    }
                ]
            },
            {   
                title:'English',
                links:[
                    {
                        imgSrc:'/media/img/part1_title.png',
                        link: 'https://drive.google.com/file/d/1whhaR0c5dYNUZsQ8ucvBdAtirsSCHjsB/view?usp=sharing',
                        title: 'Textbook Eps-topik part 1',
                        adsslot: '8882564828'
                    },
                    {
                        imgSrc:'/media/img/part2_title.png',
                        link: 'https://drive.google.com/file/d/1-i7aQfRoBewomS4ybZE1ne_XVjHccGnb/view?usp=sharing',
                        title: 'Textbook Eps-topik part 2',
                        adsslot: '3975230765'
                    }
                ]
            }
        ],
        headding: 'Sách giáo trình 60 bài'
    },
    {
        down:[
            {   
                title:'Audio file giáo trình 60 bài',
                links:[
                    {
                        imgSrc:'/media/img/audiofile1.jpg',
                        link: 'https://drive.google.com/file/d/1PjeiNFl2gdb579eqP3iolPU74sCbzr6d/view?usp=sharing',
                        title: 'Audio file EPS-TOPIK 1',
                        adsslot: '1878430903'
                    },
                    {
                        imgSrc:'/media/img/audiofile2.jpg',
                        link: 'https://drive.google.com/file/d/1QfeLOLi-EEJKTjxnBXJVfOoZYfPUTO1P/view?usp=sharing',
                        title: 'Audio file EPS-TOPIK 2',
                        adsslot: '5695506544'
                    }
                ]
            }
        ],
        headding: 'Audio file'
    },
    {
        down:[
            {   
                title:'Audio hội thoại',
                links:[
                    {
                        imgSrc:'/media/img/conversation.jpg',
                        link: 'https://drive.google.com/file/d/1iM1RzGp8k5wMXYcWEXzbthLOVSb3GUfX/view?usp=sharing',
                        title: 'Conversations - 60 lessons',
                        adsslot: '3972179579'
                    }
                ]
            }
        ],
        headding: 'File nghe hội thoại 60 bài'
    },
    {
        down:[
            {   
                title:'Giáo trình',
                links:[
                    {
                        imgSrc:'/media/img/book-50.jpg',
                        link: 'https://drive.google.com/file/d/1gfSMzc8c5ekdfkduAAPHO_9VKCM5CAkB/view?usp=sharing',
                        title: 'Sách giáo trình 50 bài',
                        adsslot: '3780607881'
                    }
                ]
            },
            {   
                title:'File nghe hội thoại',
                links:[
                    {
                        imgSrc:'/media/img/book-50-audio.jpg',
                        link: 'https://drive.google.com/file/d/1WmXF1OKv1Ke81VlVRh1OAlNb6HgaJ_ch/view?usp=sharing',
                        title: 'Hội thoại giáo trình 50 bài',
                        adsslot: '3589036196'
                    }
                ]
            }
        ],
        headding: 'Sách giáo trình 50 bài'
    },
    {
        down:[
            {   
                title:'Phần nghe textbook',
                links:[
                    {
                        imgSrc:'/media/img/listen_title.jpg',
                        link: 'https://drive.google.com/drive/folders/1BN6gdyZ1QaxzOj7KCunulNjKIu7hZzTx?usp=sharing',
                        title: 'Eps-topik listen textbook',
                        adsslot: '9771301169'
                    }
                ]
            },
            {   
                title:'Phần đọc text book',
                links:[
                    {
                        imgSrc:'/media/img/read1-480.jpg',
                        link: 'https://drive.google.com/file/d/0B-36XviPxoMLLVFJWC01OUJLLUE/view?usp=sharing',
                        title: 'Eps-topik read 1-480',
                        adsslot: '8868464797'
                    },
                    {
                        imgSrc:'/media/img/read481-960.jpg',
                        link: 'https://drive.google.com/file/d/0B-36XviPxoMLdlQ5V1A0REhZR1k/view?usp=sharing',
                        title: 'Eps-topik read 481-960',
                        adsslot: '3616138113'
                    }
                ]
            }
        ],
        headding: 'Ngân hàng 2000 câu hỏi'
    },
    {
        down:[
            {   
                title:'Audio 1000 câu nghe',
                links:[
                    {
                        imgSrc:'/media/img/audio1-160.jpg',
                        link: 'https://drive.google.com/drive/folders/1ELYBrUcr-AG2eteWahiULs_jLFnjBlw7?usp=sharing',
                        title: 'Eps-topik listen 1-160',
                        adsslot: '3424566421'
                    },
                    {
                        imgSrc:'/media/img/audio161-360.jpg',
                        link: 'https://drive.google.com/drive/folders/1OXeEoDbVitlhtUAO7f6ICxpM4_zxIi1C?usp=sharing',
                        title: 'Eps-topik listen 161-360',
                        adsslot: '7079620847'
                    },
                    {
                        imgSrc:'/media/img/audio361-480.jpg',
                        link: 'https://drive.google.com/drive/folders/1DQVLfoDJ2WYrzmzz58jlOvvKg2P-s0ue?usp=sharing',
                        title: 'Eps-topik listen 361-480',
                        adsslot: '8201130821'
                    },
                    {
                        imgSrc:'/media/img/audio481-680.jpg',
                        link: 'https://drive.google.com/drive/folders/1hGgbChSZ0wXfsRv0t_rHPgmW4saPqc0z?usp=sharing',
                        title: 'Eps-topik listen 481-680',
                        adsslot: '8009559138'
                    },
                    {
                        imgSrc:'/media/img/audio681-920.jpg',
                        link: 'https://drive.google.com/drive/folders/15BNZBpDI9wqjZA3kRylmhGd4uRtf8lNn?usp=sharing',
                        title: 'Eps-topik listen 681-920',
                        adsslot: '8573769561'
                    },
                    {
                        imgSrc:'/media/img/audio921-960.jpg',
                        link: 'https://drive.google.com/drive/folders/1XTOp25u4vMFvtf2CLZlwV14cMM1xqVb4?usp=sharing',
                        title: 'Eps-topik listen 921-960',
                        adsslot: '9005014409'
                    }
                ]
            }
        ],
        headding: 'File audio bộ đề nghe'
    },
]

window.listChapterDetail = [
    {
        id: 1,
        goLink: '/Chapter1/Lesson=1-1',
        chapter: 'Chapter1',
        lessonLabel: 'EPS-TOPIK I',
        description: 'Khóa học dành riêng cho các bạn học để tham gia kỳ thi eps xuất khẩu lao động ...',
        mark: 'lesson'
    },
    {
        id: 2,
        goLink: '/Chapter2/Lesson=31-1',
        chapter: 'Chapter2',
        lessonLabel: 'EPS-TOPIK II',
        description: 'Khóa học dành riêng cho các bạn học để tham gia kỳ thi eps xuất khẩu lao động ...',
        mark: 'lesson'
    },
    {
        id: 3,
        goLink: '/Practice-read/1-20(1)',
        chapter: 'Practice-read',
        lessonLabel: 'Ôn bộ đề 960 câu đọc',
        description: 'Hướng dẫn ôn bộ đề để chuẩn bị kiến thức, làm quen dạng đề để các bạn tự tin bước vào kỳ thi ...',
        mark: 'practice'
    },
    {
        id: 4,
        goLink: '/Practice-listen/1-20(1)',
        chapter: 'Practice-listen',
        lessonLabel: 'Ôn bộ đề 960 câu nghe',
        description: 'Hướng dẫn ôn bộ đề để chuẩn bị kiến thức, làm quen dạng đề để các bạn tự tin bước vào kỳ thi ...',
        mark: 'practice'
    }
]